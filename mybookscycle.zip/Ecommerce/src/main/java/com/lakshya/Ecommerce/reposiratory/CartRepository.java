package com.lakshya.Ecommerce.reposiratory;

import com.lakshya.Ecommerce.model.CartItem;
import com.lakshya.Ecommerce.model.User;
import com.lakshya.Ecommerce.model.Book;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface CartRepository extends JpaRepository<CartItem, Long> {
    List<CartItem> findByUser(User user);
    Optional<CartItem> findByUserAndBook(User user, Book book);
    void deleteByUser(User user);
}
