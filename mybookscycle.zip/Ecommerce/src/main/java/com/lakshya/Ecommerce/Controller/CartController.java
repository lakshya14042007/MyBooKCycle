package com.lakshya.Ecommerce.Controller;

import com.lakshya.Ecommerce.Service.CartService;
import com.lakshya.Ecommerce.model.CartItem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/cart")
@CrossOrigin(origins = "*")
public class CartController {

    @Autowired
    private CartService cartService;

    private String currentEmail() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return auth.getName();
    }

    @GetMapping
    public ResponseEntity<List<CartItem>> getCart() {
        return ResponseEntity.ok(cartService.getCart(currentEmail()));
    }

    @PostMapping("/add/{bookId}")
    public ResponseEntity<CartItem> addToCart(@PathVariable Long bookId) {
        return ResponseEntity.ok(cartService.addToCart(currentEmail(), bookId));
    }

    @PutMapping("/update/{cartItemId}")
    public ResponseEntity<?> updateQuantity(
            @PathVariable Long cartItemId,
            @RequestBody Map<String, Integer> body) {
        int qty = body.getOrDefault("quantity", 1);
        CartItem updated = cartService.updateQuantity(currentEmail(), cartItemId, qty);
        if (updated == null) return ResponseEntity.ok(Map.of("message", "Item removed"));
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/remove/{cartItemId}")
    public ResponseEntity<Map<String, String>> removeItem(@PathVariable Long cartItemId) {
        cartService.removeFromCart(currentEmail(), cartItemId);
        return ResponseEntity.ok(Map.of("message", "Removed"));
    }

    @DeleteMapping("/clear")
    public ResponseEntity<Map<String, String>> clearCart() {
        cartService.clearCart(currentEmail());
        return ResponseEntity.ok(Map.of("message", "Cart cleared"));
    }
}
