package com.lakshya.Ecommerce.Service;

import com.lakshya.Ecommerce.model.Book;
import com.lakshya.Ecommerce.model.User;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import com.lakshya.Ecommerce.reposiratory.BookRepository;

import java.util.List;
import java.util.Optional;

@Service
public class AddBookservice {

    @Autowired
    private BookRepository repo;

    public void addbook(Book book) {
        repo.save(book);
    }

    public Page<Book> getBooksPaginated(int pageNumber, int pageSize) {
        Pageable pageable = PageRequest.of(pageNumber, pageSize);
        return repo.findAll(pageable);
    }

    public Page<Book> searchBooks(String q, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        return repo.searchBooks(q, pageable);
    }

    public List<Book> getBooksBySeller(User seller) {
        return repo.findBySeller(seller);
    }

    public Optional<Book> getBookById(Long id) {
        return repo.findById(id);
    }

    public List<Book> getSimilarBooks(String author, Long excludeId) {
        Pageable limit = PageRequest.of(0, 6);
        return repo.findSimilarByAuthor(author, excludeId, limit);
    }

    public boolean deleteBook(Long bookId, User seller) {
        return repo.findById(bookId).map(book -> {
            if (book.getSeller().getId() == seller.getId()) {
                repo.deleteById(bookId);
                return true;
            }
            return false;
        }).orElse(false);
    }
}
