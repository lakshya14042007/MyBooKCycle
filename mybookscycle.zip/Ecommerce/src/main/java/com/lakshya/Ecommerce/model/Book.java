package com.lakshya.Ecommerce.model;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;

@Entity(name = "books")
public class Book {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long Id;
	
	private String name;
	private String author;
	private BigDecimal Original_price;
	private BigDecimal Selling_price;
	private String status;
	

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	@Lob
    @Column(columnDefinition = "CLOB") 
    private String image;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="seller_id",nullable=false)
	@JsonIgnore 
	private User seller;

	public long getId() {
		return Id;
	}

	public void setId(long id) {
		Id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	
	public BigDecimal getOriginal_price() {
		return Original_price;
	}

	public void setOriginal_price(BigDecimal original_price) {
		Original_price = original_price;
	}

	public BigDecimal getSelling_price() {
		return Selling_price;
	}

	public void setSelling_price(BigDecimal selling_price) {
		Selling_price = selling_price;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public User getSeller() {
		return seller;
	}

	public void setSeller(User seller) {
		this.seller = seller;
	}

	public Book() {
		super();
	}
	
}
