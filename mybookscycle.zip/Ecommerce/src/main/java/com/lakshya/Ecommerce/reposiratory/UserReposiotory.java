package com.lakshya.Ecommerce.reposiratory;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.lakshya.Ecommerce.model.User;

@Repository
public interface UserReposiotory extends JpaRepository<User,Long>{
	Optional<User> findByemail(String email);
	boolean existsByemail(String email);
	
}
