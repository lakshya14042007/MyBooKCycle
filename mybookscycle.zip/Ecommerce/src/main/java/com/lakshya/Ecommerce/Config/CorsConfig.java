package com.lakshya.Ecommerce.Config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

import java.util.Arrays;

@Configuration
public class CorsConfig {

    @Bean
    public CorsFilter corsFilter() {
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        CorsConfiguration config = new CorsConfiguration();

        // 1. Explicitly allow the React frontend URL
        config.setAllowedOrigins(Arrays.asList("http://localhost:5173"));
        
        // 2. Allow all necessary HTTP methods, especially OPTIONS for preflight
        config.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        
        // 3. Explicitly allow your custom header ("token") along with standard ones
        config.setAllowedHeaders(Arrays.asList("Authorization", "Content-Type", "token"));
        
        // 4. Allow credentials if you plan to use HTTP-only cookies later
        config.setAllowCredentials(true);

        // Apply this configuration to all endpoints
        source.registerCorsConfiguration("/**", config);
        return new CorsFilter(source);
    }
}