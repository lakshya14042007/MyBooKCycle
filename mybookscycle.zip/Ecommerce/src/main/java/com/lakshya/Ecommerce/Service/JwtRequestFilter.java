package com.lakshya.Ecommerce.Service;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component
public class JwtRequestFilter extends OncePerRequestFilter{
	private final CustomUserDetailsService userDetailsService;
    private final JwtUtil jwtUtil;

    public JwtRequestFilter(CustomUserDetailsService userDetailsService, JwtUtil jwtUtil) {
        this.userDetailsService = userDetailsService;
        this.jwtUtil = jwtUtil;
    }
    
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
    	final String authroizationHeader=request.getHeader("Authorization");
    	
    	String username=null;
    	String jwt=null;
    	
    	if(authroizationHeader != null && authroizationHeader.startsWith("Bearer ")) {
    	    jwt = authroizationHeader.substring(7);
    	    try {
    	        username = jwtUtil.extractUsername(jwt);
    	    } catch(Exception e) {
    	        logger.error("JWT Error: " + e.getMessage()); 
    	    }
    	}    	
    	if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {

            UserDetails userDetails = this.userDetailsService.loadUserByUsername(username);

            // Agar token valid hai, toh manually authenticate karo
            if (jwtUtil.validateToken(jwt, userDetails)) {

                UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = 
                        new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
                
                usernamePasswordAuthenticationToken
                        .setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                
                // Security Context mein set karne ka matlab hai user ab logged in hai
                SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
            }else {
                logger.error("TOKEN VALIDATION FAILED for user: " + username); // ← add karo
            }
        }
    	
    	filterChain.doFilter(request, response);
    }
    
    
    

}
