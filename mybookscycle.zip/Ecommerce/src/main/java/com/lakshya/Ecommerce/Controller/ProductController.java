package com.lakshya.Ecommerce.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import com.lakshya.Ecommerce.Service.AddBookservice;
import com.lakshya.Ecommerce.model.Book;
import com.lakshya.Ecommerce.model.User;
import com.lakshya.Ecommerce.reposiratory.UserReposiotory;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class ProductController {

    @Autowired
    private AddBookservice addservice;

    @Autowired
    private UserReposiotory userRepo;

    private User getCurrentUser() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated() ||
            "anonymousUser".equals(auth.getPrincipal())) return null;
        return userRepo.findByemail(auth.getName()).orElse(null);
    }

    // POST /api/AddProduct
    @PostMapping("/AddProduct")
    public ResponseEntity<String> addProduct(@RequestBody Book book) {
        try {
            User seller = getCurrentUser();
            if (seller == null)
                return new ResponseEntity<>("Unauthorized", HttpStatus.FORBIDDEN);
            book.setSeller(seller);
            addservice.addbook(book);
            return new ResponseEntity<>("Book Successfully Added", HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>("SYSTEM ERROR: " + e.getMessage(),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // GET /api/books
    @GetMapping("/books")
    public ResponseEntity<Page<Book>> showBooks(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "12") int size) {
        return ResponseEntity.ok(addservice.getBooksPaginated(page, size));
    }

    // GET /api/books/search
    @GetMapping("/books/search")
    public ResponseEntity<Page<Book>> searchBooks(
            @RequestParam String q,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "12") int size) {
        return ResponseEntity.ok(addservice.searchBooks(q, page, size));
    }

    // GET /api/books/{id}  ← book details
    @GetMapping("/books/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable Long id) {
        return addservice.getBookById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // GET /api/books/{id}/similar  ← similar books by same author
    @GetMapping("/books/{id}/similar")
    public ResponseEntity<List<Book>> getSimilarBooks(@PathVariable Long id) {
        return addservice.getBookById(id).map(book -> {
            List<Book> similar = addservice.getSimilarBooks(book.getAuthor(), id);
            return ResponseEntity.ok(similar);
        }).orElse(ResponseEntity.notFound().build());
    }

    // GET /api/my-books
    @GetMapping("/my-books")
    public ResponseEntity<List<Book>> getMyBooks() {
        User seller = getCurrentUser();
        if (seller == null)
            return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        return ResponseEntity.ok(addservice.getBooksBySeller(seller));
    }

    // DELETE /api/my-books/{bookId}
    @DeleteMapping("/my-books/{bookId}")
    public ResponseEntity<String> deleteMyBook(@PathVariable Long bookId) {
        User seller = getCurrentUser();
        if (seller == null)
            return new ResponseEntity<>("Unauthorized", HttpStatus.UNAUTHORIZED);
        boolean deleted = addservice.deleteBook(bookId, seller);
        if (deleted) return ResponseEntity.ok("Book deleted");
        return new ResponseEntity<>("Not found or not yours", HttpStatus.FORBIDDEN);
    }
}
