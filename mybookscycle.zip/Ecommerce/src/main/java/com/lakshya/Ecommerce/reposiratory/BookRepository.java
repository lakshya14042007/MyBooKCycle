package com.lakshya.Ecommerce.reposiratory;

import com.lakshya.Ecommerce.model.Book;
import com.lakshya.Ecommerce.model.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface BookRepository extends JpaRepository<Book, Long> {

    // Search by title or author
    @Query("SELECT b FROM books b WHERE " +
           "LOWER(b.name) LIKE LOWER(CONCAT('%', :q, '%')) OR " +
           "LOWER(b.author) LIKE LOWER(CONCAT('%', :q, '%'))")
    Page<Book> searchBooks(@Param("q") String q, Pageable pageable);

    // Books by seller
    List<Book> findBySeller(User seller);

    // Similar books - same author, exclude current book, limit 6
    @Query("SELECT b FROM books b WHERE b.author = :author AND b.id <> :excludeId")
    List<Book> findSimilarByAuthor(@Param("author") String author,
                                   @Param("excludeId") Long excludeId,
                                   Pageable pageable);
}
