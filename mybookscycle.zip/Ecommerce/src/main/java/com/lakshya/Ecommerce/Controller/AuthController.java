package com.lakshya.Ecommerce.Controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import com.lakshya.Ecommerce.Service.CustomUserDetailsService;
import com.lakshya.Ecommerce.Service.JwtUtil;
import com.lakshya.Ecommerce.model.User;
import com.lakshya.Ecommerce.reposiratory.UserReposiotory;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth") 
@CrossOrigin(origins = "*") 
public class AuthController {

   
    private final AuthenticationManager authenticationManager;
    private final CustomUserDetailsService userDetailsService;
    private final JwtUtil jwtUtil;
    private final UserReposiotory userRepository;
    private final PasswordEncoder passwordEncoder;

    public AuthController(AuthenticationManager authenticationManager, 
                          CustomUserDetailsService userDetailsService, 
                          JwtUtil jwtUtil, 
                          UserReposiotory userRepository, 
                          PasswordEncoder passwordEncoder) {
        this.authenticationManager = authenticationManager;
        this.userDetailsService = userDetailsService;
        this.jwtUtil = jwtUtil;
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

  
    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody User user) {

    	
        if (userRepository.existsByemail(user.getEmail())) {
           
        	return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Error: Email is already in use!");
        }

      
        user.setPassword(passwordEncoder.encode(user.getPassword()));

      
        if (user.getRole() == null || user.getRole().isEmpty()) {
            user.setRole("ROLE_USER");
        }

        userRepository.save(user);

       
        return ResponseEntity.ok("User registered successfully!");
    }

    
    @PostMapping("/login")
    public ResponseEntity<?> loginUser(@RequestBody Map<String, String> loginRequest) {
     
        String email = loginRequest.get("email");
        String password = loginRequest.get("password");

        try {
           
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(email, password)
            );
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid email or password");
        }

        final UserDetails userDetails = userDetailsService.loadUserByUsername(email);

        
        final String jwtToken = jwtUtil.generateToken(userDetails);

       
        Map<String, String> response = new HashMap<>();
        response.put("token", jwtToken);

        return ResponseEntity.ok(response);
    }
    
    @GetMapping("/auth/profile")
    public ResponseEntity<?> getProfile(Authentication auth) {
        User user = userRepository.findByemail(auth.getName()).orElseThrow();
        return ResponseEntity.ok(Map.of(
            "email", user.getEmail(),
            "name",  user.getName() // agar naam field hai toh
        ));
    }
}