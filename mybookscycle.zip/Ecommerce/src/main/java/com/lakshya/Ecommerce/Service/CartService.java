package com.lakshya.Ecommerce.Service;

import com.lakshya.Ecommerce.model.Book;
import com.lakshya.Ecommerce.model.CartItem;
import com.lakshya.Ecommerce.model.User;
import com.lakshya.Ecommerce.reposiratory.BookRepository;
import com.lakshya.Ecommerce.reposiratory.CartRepository;
import com.lakshya.Ecommerce.reposiratory.UserReposiotory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class CartService {

    @Autowired
    private CartRepository cartRepo;

    @Autowired
    private BookRepository bookRepo;

    @Autowired
    private UserReposiotory userRepo;

    public List<CartItem> getCart(String email) {
        User user = userRepo.findByemail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));
        return cartRepo.findByUser(user);
    }

    @Transactional
    public CartItem addToCart(String email, Long bookId) {
        User user = userRepo.findByemail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));
        Book book = bookRepo.findById(bookId)
                .orElseThrow(() -> new RuntimeException("Book not found"));

        Optional<CartItem> existing = cartRepo.findByUserAndBook(user, book);
        if (existing.isPresent()) {
            CartItem item = existing.get();
            item.setQuantity(item.getQuantity() + 1);
            return cartRepo.save(item);
        }
        return cartRepo.save(new CartItem(user, book, 1));
    }

    @Transactional
    public CartItem updateQuantity(String email, Long cartItemId, int quantity) {
        CartItem item = cartRepo.findById(cartItemId)
                .orElseThrow(() -> new RuntimeException("Cart item not found"));

        if (!item.getUser().getEmail().equals(email)) {
            throw new RuntimeException("Unauthorized");
        }

        if (quantity <= 0) {
            cartRepo.delete(item);
            return null;
        }
        item.setQuantity(quantity);
        return cartRepo.save(item);
    }

    @Transactional
    public void removeFromCart(String email, Long cartItemId) {
        CartItem item = cartRepo.findById(cartItemId)
                .orElseThrow(() -> new RuntimeException("Cart item not found"));
        if (!item.getUser().getEmail().equals(email)) {
            throw new RuntimeException("Unauthorized");
        }
        cartRepo.delete(item);
    }

    @Transactional
    public void clearCart(String email) {
        User user = userRepo.findByemail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));
        cartRepo.deleteByUser(user);
    }
}
