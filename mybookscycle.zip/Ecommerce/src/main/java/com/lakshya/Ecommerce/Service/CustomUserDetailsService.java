package com.lakshya.Ecommerce.Service;

import java.util.ArrayList;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.lakshya.Ecommerce.model.User;
import com.lakshya.Ecommerce.reposiratory.UserReposiotory;

@Service
public class CustomUserDetailsService implements UserDetailsService{
	
	private UserReposiotory repo;
	
	

	public CustomUserDetailsService(UserReposiotory repo) {
		this.repo=repo;
	}



	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		User user=repo.findByemail(email)
				.orElseThrow(()->new UsernameNotFoundException("User not found with email: "+email));
		
		return new org.springframework.security.core.userdetails.User(
				user.getEmail(),
				user.getPassword(),
				new ArrayList<>()
				);
	}

}
