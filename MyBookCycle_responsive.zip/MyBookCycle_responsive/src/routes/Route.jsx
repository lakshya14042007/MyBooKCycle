import { createBrowserRouter } from "react-router-dom";
import App from "../App";
import Layout from "../components/Layout";
import Home from "../components/Home/Home";
import Login from "../Auth/Login";
import Register from "../Auth/Register";
import PrivateRoute from "../components/PrivateRoute";
import AddBook from "../components/AddBook/AddBook";
import SearchPage from "../components/Search/SearchPage";
import CartPage from "../components/Pages/CartPage";
import AccountPage from "../components/Pages/AccountPage";
import MyBooksPage from "../components/MyBooksPage";
import BookDetailPage from "../components/Pages/BookDetailPage";
const routes = createBrowserRouter([
    {
        path: "/",
        element: <App />, 
        children: [
            {
                path: "login",
                element: <Login />,
            },
            {
                path: "register",
                element: <Register />,
            },
            
            {
                path: "/",
                element: (
                    <PrivateRoute>
                        <Layout />
                    </PrivateRoute>
                ),
                children: [
                    {
                        path: "/", 
                        element: <Home />,
                    },
                    {
                        path: "add-book",
                        element: <AddBook />,
                    },{
                        path:"/search",
                        element:<SearchPage/>
                    },{
                        path:"/cart",
                        element:<CartPage/>
                    },{
                        path:"/account",
                        element:<AccountPage/>
                    },{
                        path:"/my-books",
                        element:<MyBooksPage />
                    },{
                        path:"/books/:id",
                        element:<BookDetailPage />
                    }
                ]
            }
        ]
    }
]);


export default routes;