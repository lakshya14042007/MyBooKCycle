import React from 'react'
import NavComponent from './navbar/NavComponent'
import { Outlet } from 'react-router-dom'
const Layout = () => {
  return (
    <>
      <NavComponent/>
      <main>
        <Outlet /> 
      </main>
    </>
  )
}

export default Layout
