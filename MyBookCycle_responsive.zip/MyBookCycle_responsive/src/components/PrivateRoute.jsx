import React, { useContext } from 'react';
import { Navigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';

const PrivateRoute = ({ children }) => {
    const { isAuthenticated } = useContext(AuthContext);

    // If not authenticated, redirect. Otherwise, render the requested component.
    return isAuthenticated ? children : <Navigate to="/login" replace />;
};

export default PrivateRoute;
