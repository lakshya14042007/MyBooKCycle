import React, { useState, useRef } from 'react';
import './AddBook.css';
import apiClient from '../../api/axiosConfig'; // Import your custom Axios instance!

const AddBook = () => {
    const [BookData, setBookData] = useState({
        name: "",
        author: "",
        Original_price: "",
        Selling_price:"",
        status: "Available",
        image: ""
    });

    const fileInputRef = useRef(null);

    const onsubmit = async (e) => {
        e.preventDefault();
        try {
            // Use apiClient instead of fetch. Notice the URL path!
            // apiClient already has base 'http://localhost:8080/api'
            // So we just need the endpoint path relative to it.
            const response = await apiClient.post("/AddProduct", BookData);

            if (response.status === 200) {
                alert("Book Added Successfully");
                setBookData({ name: "", author: "", Original_price: "", Selling_price: "", status: "Available", image: "" });
                if (fileInputRef.current) {
                    fileInputRef.current.value = "";
                }
            }
        } catch (error) {
            // Axios errors are wrapped in error.response
            const errorMsg = error.response?.data || error.message;
            alert(`Book Adding Failed: ${errorMsg}`);
            console.error("Submission Error:", error);
        }
    };

    const handleImageChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setBookData({ ...BookData, image: reader.result });
            };
            reader.readAsDataURL(file);
        }
    };

    return (
        <div className="addbook-page">
            <div className="addbook-card">
                <div className="addbook-header">
                    <div className="addbook-icon">📚</div>
                    <h1>SELL Book</h1>
                </div>

                <form onSubmit={onsubmit}>
                    <div className="form-group">
                        <label>Title</label>
                        <input
                            type="text"
                            placeholder="e.g. The Alchemist"
                            value={BookData.name}
                            onChange={(e) => setBookData({ ...BookData, name: e.target.value })}
                            required
                        />
                    </div>

                    <div className="form-row">
                        <div className="form-group">
                            <label>Author</label>
                            <input
                                type="text"
                                placeholder="Author name"
                                value={BookData.author}
                                onChange={(e) => setBookData({ ...BookData, author: e.target.value })}
                                required
                            />
                        </div>
                        <div className="form-group">
                            <label>Original Price (₹)</label>
                            <input
                                type="number"
                                step="0.01"
                                placeholder="e.g. 299"
                                value={BookData.Original_price}
                                onChange={(e) => setBookData({ ...BookData,Original_price: e.target.value })}
                                required
                            />
                        </div>
                    </div>

                    <div className="form-group">
                        <label>Selling Price (₹)</label>
                        <input
                            type="number"
                            step="0.01"
                            placeholder="e.g. 199"
                            value={BookData.Selling_price}
                            onChange={(e) => setBookData({ ...BookData, Selling_price: e.target.value })}
                            required
                        />
                    </div>

                    <div className="form-group">
                        <label>Cover Image</label>
                        <input
                            type="file"
                            accept="image/jpeg, image/png, image/jpg"
                            onChange={handleImageChange}
                            ref={fileInputRef}
                        />
                    </div>

                    <button type="submit" className="submit-btn">Add Book</button>
                </form>
            </div>
        </div>
    );
};

export default AddBook;