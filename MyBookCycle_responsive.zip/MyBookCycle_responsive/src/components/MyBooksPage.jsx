import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import apiClient from '../api/axiosConfig';

// ── Single Book Card ─────────────────────────────────────────────
const MyBookCard = ({ book, onDelete }) => {
  const [deleting, setDeleting] = useState(false);
  const [confirmOpen, setConfirmOpen] = useState(false);

  const bookId = book.id ?? book.Id;

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await apiClient.delete(`/my-books/${bookId}`);
      onDelete(bookId);
    } catch {
      alert('Delete nahi hua, dobara try karo');
    } finally {
      setDeleting(false);
      setConfirmOpen(false);
    }
  };

  const discount = book.Original_price && book.Selling_price
    ? Math.round(((book.Original_price - book.Selling_price) / book.Original_price) * 100)
    : null;

  return (
    <div style={S.card}>
      {/* Image */}
      <div style={S.imgWrap}>
        {book.image ? (
          <img src={book.image} alt={book.name} style={S.img} />
        ) : (
          <div style={S.imgPlaceholder}>
            <svg viewBox="0 0 60 80" width="48" fill="none">
              <rect width="60" height="80" rx="4" fill="#2a1f14" />
              <rect x="6" y="10" width="48" height="4" rx="2" fill="#F5C518" opacity="0.6" />
              <rect x="6" y="20" width="36" height="3" rx="1.5" fill="#F5C518" opacity="0.3" />
              <rect x="6" y="28" width="42" height="3" rx="1.5" fill="#F5C518" opacity="0.3" />
              <rect x="4" y="0" width="4" height="80" rx="2" fill="#E63946" opacity="0.7" />
            </svg>
          </div>
        )}
        {discount > 0 && (
          <span style={S.badge}>-{discount}%</span>
        )}
        {/* Status pill */}
        <span style={{
          ...S.statusPill,
          background: book.status?.toLowerCase() === 'sold'
            ? '#E63946' : '#2a6049',
        }}>
          {book.status || 'Available'}
        </span>
      </div>

      {/* Info */}
      <div style={S.body}>
        <div style={S.bookName}>{book.name}</div>
        <div style={S.bookAuthor}>by {book.author}</div>

        <div style={S.priceRow}>
          <span style={S.sellPrice}>₹{book.Selling_price}</span>
          {book.Original_price && (
            <span style={S.origPrice}>₹{book.Original_price}</span>
          )}
        </div>

        {/* Delete button / confirm */}
        {!confirmOpen ? (
          <button
            style={S.deleteBtn}
            onClick={() => setConfirmOpen(true)}
          >
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" strokeWidth="2">
              <polyline points="3 6 5 6 21 6" />
              <path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6" />
              <path d="M10 11v6M14 11v6" />
              <path d="M9 6V4a1 1 0 011-1h4a1 1 0 011 1v2" />
            </svg>
            Remove Listing
          </button>
        ) : (
          <div style={S.confirmRow}>
            <span style={{ fontSize: '0.78rem', color: '#E63946', fontWeight: 600 }}>
              Sure?
            </span>
            <button
              style={S.confirmYes}
              onClick={handleDelete}
              disabled={deleting}
            >
              {deleting ? '…' : 'Yes, Delete'}
            </button>
            <button
              style={S.confirmNo}
              onClick={() => setConfirmOpen(false)}
            >
              Cancel
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

// ── Skeleton ─────────────────────────────────────────────────────
const SkeletonCard = () => (
  <div style={{ ...S.card, pointerEvents: 'none' }}>
    <div style={{ ...S.imgWrap, background: '#e8e0d8', animation: 'shimmer 1.4s infinite' }} />
    <div style={S.body}>
      {[85, 55, 45].map((w, i) => (
        <div key={i} style={{
          height: 12, width: `${w}%`, borderRadius: 4, marginBottom: 8,
          background: 'linear-gradient(90deg,#ede8e2 25%,#f8f3ee 50%,#ede8e2 75%)',
          backgroundSize: '200% 100%', animation: 'shimmer 1.4s infinite',
        }} />
      ))}
    </div>
  </div>
);

// ── Main Page ─────────────────────────────────────────────────────
const MyBooksPage = () => {
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const fetchMyBooks = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await apiClient.get('/my-books');
      setBooks(res.data);
    } catch (err) {
      setError('Books load nahi hui. Backend check karo.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchMyBooks(); }, [fetchMyBooks]);

  // Remove deleted book from state
  const handleDelete = (deletedId) => {
    setBooks(prev => prev.filter(b => (b.id ?? b.Id) !== deletedId));
  };

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Inter:wght@400;500;600;700&display=swap');
        .mbp * { font-family: 'Inter', sans-serif; box-sizing: border-box; }
        .mbp-card { transition: transform .25s, box-shadow .25s; }
        .mbp-card:hover { transform: translateY(-5px); box-shadow: 4px 12px 28px #1a100818 !important; }
        .del-btn:hover { background: #fff0f0 !important; color: #E63946 !important; border-color: #E63946 !important; }
        .sell-btn:hover { background: #e6b800 !important; }
        @keyframes shimmer { to { background-position: -200% 0; } }
        @media (max-width: 640px) {
          .mbp-page-inner { padding: 1rem 0.9rem 3rem !important; }
          .mbp-header { flex-wrap: wrap !important; }
          .mbp-header h2 { font-size: 1.25rem !important; }
          .mbp-add-btn { margin-left: 0 !important; width: 100% !important; }
          .mbp-grid { grid-template-columns: repeat(2, 1fr) !important; gap: 0.75rem !important; }
          .mbp-stats { gap: 0.5rem !important; }
          .mbp-stat-chip { min-width: 80px !important; padding: 0.6rem 0.75rem !important; }
        }
        @media (max-width: 380px) {
          .mbp-grid { grid-template-columns: repeat(2, 1fr) !important; gap: 0.6rem !important; }
        }
      `}</style>

      <div className="mbp" style={P.page}>

        {/* ── Header ── */}
        <div style={P.header} className="mbp-header">
          <button onClick={() => navigate(-1)} style={P.backBtn}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
              <path d="M19 12H5M12 5l-7 7 7 7" />
            </svg>
          </button>
          <div>
            <h1 style={P.title}>My Listed Books</h1>
            {!loading && (
              <p style={P.subtitle}>
                {books.length === 0
                  ? 'Abhi koi book listed nahi hai'
                  : `${books.length} book${books.length > 1 ? 's' : ''} selling`}
              </p>
            )}
          </div>
          <button
            className="sell-btn"
            style={P.addBtn}
            onClick={() => navigate('/add-book')}
          >
            + Add Book
          </button>
        </div>

        {/* ── Stats bar ── */}
        {!loading && books.length > 0 && (
          <div style={P.statsBar} className="mbp-stats">
            <StatChip
              label="Total Listed"
              value={books.length}
              color="#1a1008"
            />
            <StatChip
              label="Available"
              value={books.filter(b => b.status?.toLowerCase() !== 'sold').length}
              color="#2a6049"
            />
            <StatChip
              label="Sold"
              value={books.filter(b => b.status?.toLowerCase() === 'sold').length}
              color="#E63946"
            />
            <StatChip
              label="Total Value"
              value={`₹${books.reduce((s, b) => s + (b.Selling_price ?? 0), 0).toFixed(0)}`}
              color="#c0392b"
            />
          </div>
        )}

        {/* ── Error ── */}
        {error && (
          <div style={P.errorBox}>
            <span>⚠️ {error}</span>
            <button onClick={fetchMyBooks} style={P.retryBtn}>Retry</button>
          </div>
        )}

        {/* ── Grid ── */}
        <div style={P.grid} className="mbp-grid">
          {loading
            ? Array.from({ length: 8 }).map((_, i) => <SkeletonCard key={i} />)
            : books.length > 0
              ? books.map((book) => (
                  <div key={book.id ?? book.Id} className="mbp-card" style={S.card}>
                    <MyBookCard book={book} onDelete={handleDelete} />
                  </div>
                ))
              : null
          }
        </div>

        {/* ── Empty state ── */}
        {!loading && books.length === 0 && !error && (
          <div style={P.emptyState}>
            <div style={{ fontSize: '4rem', marginBottom: '1rem' }}>📭</div>
            <p style={{ fontSize: '1.1rem', fontWeight: 700, color: '#1a1008', marginBottom: '0.5rem' }}>
              Koi book listed nahi hai abhi
            </p>
            <p style={{ color: '#8a7060', marginBottom: '1.5rem' }}>
              Apni purani books sell karo aur paise kamao!
            </p>
            <button
              className="sell-btn"
              style={{ ...P.addBtn, padding: '0.7rem 2rem' }}
              onClick={() => navigate('/sell')}
            >
              + Pehli Book List Karo
            </button>
          </div>
        )}
      </div>
    </>
  );
};

// ── Stat Chip ────────────────────────────────────────────────────
const StatChip = ({ label, value, color }) => (
  <div style={{
    background: 'white', border: '1px solid #f0e8de',
    borderRadius: 10, padding: '0.75rem 1.25rem',
    flex: 1, minWidth: 100, textAlign: 'center',
  }}>
    <div style={{ fontSize: '1.25rem', fontWeight: 700, color }}>{value}</div>
    <div style={{ fontSize: '0.72rem', color: '#8a7060', marginTop: 2 }}>{label}</div>
  </div>
);

// ── Card Styles ──────────────────────────────────────────────────
const S = {
  card: {
    background: 'white', borderRadius: 10,
    border: '1px solid #f0e8de', overflow: 'hidden',
  },
  imgWrap: {
    position: 'relative', aspectRatio: '3/4',
    background: '#f5ebe0', overflow: 'hidden',
  },
  img: { width: '100%', height: '100%', objectFit: 'cover', display: 'block' },
  imgPlaceholder: {
    width: '100%', height: '100%',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    background: 'linear-gradient(135deg,#2a1f14,#4a3525)',
  },
  badge: {
    position: 'absolute', top: 8, left: 8,
    background: '#E63946', color: '#fff',
    fontSize: '0.68rem', fontWeight: 700,
    padding: '3px 7px', borderRadius: 4,
  },
  statusPill: {
    position: 'absolute', bottom: 8, right: 8,
    color: '#fff', fontSize: '0.65rem', fontWeight: 700,
    textTransform: 'uppercase', letterSpacing: '0.5px',
    padding: '3px 8px', borderRadius: 20,
  },
  body: { padding: '0.85rem' },
  bookName: {
    fontWeight: 700, fontSize: '0.9rem', color: '#1a1008',
    marginBottom: 2, lineHeight: 1.3,
    display: '-webkit-box', WebkitLineClamp: 2,
    WebkitBoxOrient: 'vertical', overflow: 'hidden',
  },
  bookAuthor: { fontSize: '0.75rem', color: '#8a7060', marginBottom: '0.5rem' },
  priceRow: { display: 'flex', alignItems: 'baseline', gap: '0.4rem', marginBottom: '0.75rem' },
  sellPrice: { fontSize: '1rem', fontWeight: 700, color: '#E63946' },
  origPrice: { fontSize: '0.75rem', color: '#aaa', textDecoration: 'line-through' },
  deleteBtn: {
    width: '100%', padding: '0.45rem',
    background: 'white', color: '#8a7060',
    border: '1.5px solid #e0d8ce', borderRadius: 6,
    fontSize: '0.78rem', fontWeight: 600, cursor: 'pointer',
    display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 5,
    transition: 'background .15s, color .15s, border-color .15s',
  },
  confirmRow: {
    display: 'flex', alignItems: 'center',
    gap: '0.4rem', marginTop: 2,
  },
  confirmYes: {
    flex: 1, padding: '0.4rem 0',
    background: '#E63946', color: '#fff',
    border: 'none', borderRadius: 6,
    fontSize: '0.75rem', fontWeight: 700, cursor: 'pointer',
  },
  confirmNo: {
    flex: 1, padding: '0.4rem 0',
    background: 'white', color: '#8a7060',
    border: '1.5px solid #e0d8ce', borderRadius: 6,
    fontSize: '0.75rem', cursor: 'pointer',
  },
};

// ── Page Styles ──────────────────────────────────────────────────
const P = {
  page: { maxWidth: 1280, margin: '0 auto', padding: '1.5rem 1.25rem 4rem' },
  header: {
    display: 'flex', alignItems: 'center', gap: '1rem',
    marginBottom: '1.5rem', flexWrap: 'wrap',
  },
  backBtn: {
    background: '#1a1008', border: 'none', color: '#F5C518',
    width: 38, height: 38, borderRadius: '50%',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    cursor: 'pointer', flexShrink: 0,
  },
  title: {
    fontFamily: "'Playfair Display', serif",
    fontSize: '1.5rem', fontWeight: 700,
    color: '#1a1008', margin: 0,
  },
  subtitle: { fontSize: '0.82rem', color: '#8a7060', margin: '2px 0 0' },
  addBtn: {
    marginLeft: 'auto', background: '#F5C518', color: '#1a1008',
    border: 'none', borderRadius: 8,
    padding: '0.55rem 1.25rem',
    fontWeight: 700, fontSize: '0.88rem', cursor: 'pointer',
    transition: 'background .2s',
  },
  statsBar: {
    display: 'flex', gap: '0.75rem', marginBottom: '1.5rem', flexWrap: 'wrap',
    overflowX: 'auto', paddingBottom: 4,
  },
  grid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))',
    gap: '1.25rem',
  },
  emptyState: { textAlign: 'center', padding: '5rem 2rem' },
  errorBox: {
    display: 'flex', alignItems: 'center', gap: '1rem',
    background: '#fff0f0', border: '1px solid #ffcccc',
    borderRadius: 8, padding: '1rem 1.25rem',
    marginBottom: '1.5rem', color: '#E63946',
  },
  retryBtn: {
    background: '#1a1008', color: '#F5C518',
    border: 'none', borderRadius: 6,
    padding: '0.4rem 1rem', fontSize: '0.82rem',
    fontWeight: 600, cursor: 'pointer',
  },
};

export default MyBooksPage;
