import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import apiClient from '../../api/axiosConfig';

const Searchbar = ({ onSearch }) => {
  const [query, setQuery] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [highlighted, setHighlighted] = useState(-1);

  const navigate = useNavigate();
  const wrapperRef = useRef(null);
  const debounceRef = useRef(null);

  useEffect(() => {
    const handleClick = (e) => {
      if (wrapperRef.current && !wrapperRef.current.contains(e.target)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  const fetchSuggestions = useCallback((q) => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (!q.trim() || q.length < 2) {
      setSuggestions([]);
      setOpen(false);
      return;
    }
    debounceRef.current = setTimeout(async () => {
      setLoading(true);
      try {
        const res = await apiClient.get('/books/search', { params: { q, page: 0, size: 6 } });
        const books = res.data?.content ?? res.data ?? [];
        setSuggestions(books.slice(0, 6));
        setOpen(true);
        setHighlighted(-1);
      } catch {
        setSuggestions([]);
      } finally {
        setLoading(false);
      }
    }, 280);
  }, []);

  const handleChange = (e) => {
    const val = e.target.value;
    setQuery(val);
    fetchSuggestions(val);
  };

  const goToSearch = (q) => {
    const term = q || query;
    if (!term.trim()) return;
    setOpen(false);
    setQuery(term);
    navigate(`/search?q=${encodeURIComponent(term.trim())}`);
    if (onSearch) onSearch();
  };

  const handleKeyDown = (e) => {
    if (!open) return;
    if (e.key === 'ArrowDown') {
      setHighlighted((h) => Math.min(h + 1, suggestions.length - 1));
    } else if (e.key === 'ArrowUp') {
      setHighlighted((h) => Math.max(h - 1, -1));
    } else if (e.key === 'Enter') {
      if (highlighted >= 0 && suggestions[highlighted]) {
        goToSearch(suggestions[highlighted].name);
      } else {
        goToSearch();
      }
    } else if (e.key === 'Escape') {
      setOpen(false);
    }
  };

  return (
    <>
      <style>{`
        .sb-wrapper { position: relative; width: 100%; }
        .sb-input-row {
          display: flex; align-items: center;
          background: white; border-radius: 20px;
          border: 2px solid #1a1a1a; overflow: hidden; height: 38px;
        }
        .sb-input {
          flex: 1; border: none; outline: none;
          padding: 0 12px; font-size: 0.85rem;
          font-family: Inter, sans-serif;
          background: transparent; color: #1a1a1a; min-width: 0;
        }
        .sb-btn {
          background: #1a1a1a; border: none; color: #F5C518;
          width: 38px; height: 38px;
          display: flex; align-items: center; justify-content: center;
          cursor: pointer; flex-shrink: 0; transition: background 0.2s;
        }
        .sb-dropdown {
          position: absolute; top: calc(100% + 6px); left: 0; right: 0;
          background: white; border-radius: 12px;
          box-shadow: 0 8px 32px rgba(0,0,0,0.15);
          border: 1px solid #f0e8de; z-index: 9999;
          overflow: hidden; min-width: 280px;
        }
        .sb-suggestion {
          display: flex; align-items: center; gap: 10px;
          padding: 10px 14px; cursor: pointer;
          transition: background 0.15s; border-bottom: 1px solid #f5f0ea;
        }
        .sb-suggestion:hover { background: #fff3c4; }
        .sb-view-all {
          padding: 10px 14px; font-size: 0.82rem;
          color: #c0392b; cursor: pointer;
          background: #fffbf0; text-align: center; font-weight: 500;
        }
        .sb-empty { padding: 14px 16px; font-size: 0.85rem; color: #8a7060; text-align: center; }
        .sb-loading { display: flex; justify-content: center; gap: 6px; padding: 14px; }
        .sb-dot {
          width: 7px; height: 7px; border-radius: 50%;
          background: #F5C518; animation: sb-pulse 1s infinite; display: inline-block;
        }
        .sb-dot:nth-child(2) { animation-delay: 0.15s; }
        .sb-dot:nth-child(3) { animation-delay: 0.3s; }
        @keyframes sb-pulse { 0%,100%{opacity:.4;transform:scale(.8)} 50%{opacity:1;transform:scale(1)} }
        @media (max-width: 768px) {
          .sb-wrapper { width: 100%; }
          .sb-dropdown { min-width: unset; }
        }
      `}</style>

      <div ref={wrapperRef} className="sb-wrapper">
        <div className="sb-input-row">
          <input
            type="text"
            value={query}
            onChange={handleChange}
            onKeyDown={handleKeyDown}
            onFocus={() => suggestions.length > 0 && setOpen(true)}
            placeholder="Search books, authors…"
            className="sb-input"
            aria-label="Search books"
            autoComplete="off"
          />
          <button onClick={() => goToSearch()} className="sb-btn" aria-label="Search">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
              <circle cx="11" cy="11" r="8" />
              <path d="m21 21-4.35-4.35" />
            </svg>
          </button>
        </div>

        {open && (
          <div className="sb-dropdown">
            {loading && (
              <div className="sb-loading">
                <span className="sb-dot" /><span className="sb-dot" /><span className="sb-dot" />
              </div>
            )}
            {!loading && suggestions.length === 0 && query.length >= 2 && (
              <div className="sb-empty">No results for "<strong>{query}</strong>"</div>
            )}
            {!loading && suggestions.map((book, i) => (
              <div
                key={book.id ?? book.Id ?? i}
                className="sb-suggestion"
                style={{ background: highlighted === i ? '#fff3c4' : 'white' }}
                onMouseEnter={() => setHighlighted(i)}
                onMouseLeave={() => setHighlighted(-1)}
                onMouseDown={() => goToSearch(book.name)}
              >
                <span style={{ fontSize: '1.1rem', flexShrink: 0 }}>📖</span>
                <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column' }}>
                  <span style={{ fontSize: '0.88rem', color: '#1a1008', fontWeight: 500,
                    whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                    {highlightMatch(book.name, query)}
                  </span>
                  <span style={{ fontSize: '0.75rem', color: '#8a7060' }}>{book.author}</span>
                </div>
                {book.Selling_price && (
                  <span style={{ fontSize: '0.85rem', fontWeight: 700, color: '#E63946', flexShrink: 0 }}>
                    ₹{book.Selling_price}
                  </span>
                )}
              </div>
            ))}
            {!loading && suggestions.length > 0 && (
              <div className="sb-view-all" onMouseDown={() => goToSearch()}>
                View all results for "<strong>{query}</strong>" →
              </div>
            )}
          </div>
        )}
      </div>
    </>
  );
};

function highlightMatch(text, query) {
  if (!query || !text) return text;
  const idx = text.toLowerCase().indexOf(query.toLowerCase());
  if (idx === -1) return text;
  return (
    <>
      {text.slice(0, idx)}
      <strong style={{ color: '#c0392b' }}>{text.slice(idx, idx + query.length)}</strong>
      {text.slice(idx + query.length)}
    </>
  );
}

export default Searchbar;
