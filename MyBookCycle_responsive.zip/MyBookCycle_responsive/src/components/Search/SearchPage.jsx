import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import apiClient from '../../api/axiosConfig';

const BookCard = ({ book, onClick }) => {
  const discount = book.Original_price && book.Selling_price
    ? Math.round(((book.Original_price - book.Selling_price) / book.Original_price) * 100)
    : null;

  return (
    <div style={cardStyles.card} onClick={onClick}
      onMouseEnter={e => {
        e.currentTarget.style.transform = 'translateY(-5px)';
        e.currentTarget.style.boxShadow = '4px 10px 28px #1a100818';
      }}
      onMouseLeave={e => {
        e.currentTarget.style.transform = 'translateY(0)';
        e.currentTarget.style.boxShadow = 'none';
      }}
    >
      <div style={cardStyles.imgWrap}>
        {book.image ? (
          <img src={book.image} alt={book.name} style={cardStyles.img} />
        ) : (
          <div style={cardStyles.placeholder}>
            <svg viewBox="0 0 60 80" width="50" fill="none">
              <rect width="60" height="80" rx="4" fill="#2a1f14" />
              <rect x="6" y="10" width="48" height="4" rx="2" fill="#F5C518" opacity="0.6" />
              <rect x="6" y="20" width="36" height="3" rx="1.5" fill="#F5C518" opacity="0.3" />
              <rect x="6" y="28" width="42" height="3" rx="1.5" fill="#F5C518" opacity="0.3" />
              <rect x="4" y="0" width="4" height="80" rx="2" fill="#E63946" opacity="0.7" />
            </svg>
          </div>
        )}
        {discount > 0 && (
          <span style={cardStyles.badge}>-{discount}%</span>
        )}
        {/* Hover overlay */}
        <div style={cardStyles.overlay}>
          <span style={cardStyles.overlayText}>View Details →</span>
        </div>
      </div>
      <div style={cardStyles.body}>
        <div style={cardStyles.title}>{book.name}</div>
        <div style={cardStyles.author}>by {book.author}</div>
        <div style={cardStyles.priceRow}>
          <span style={cardStyles.sellPrice}>₹{book.Selling_price}</span>
          {book.Original_price && (
            <span style={cardStyles.origPrice}>₹{book.Original_price}</span>
          )}
        </div>
        <button
          style={cardStyles.btn}
          onClick={e => { e.stopPropagation(); onClick(); }}
        >
          View Details
        </button>
      </div>
    </div>
  );
};

const SkeletonCard = () => (
  <div style={{ ...cardStyles.card, pointerEvents: 'none' }}>
    <div style={{ ...cardStyles.imgWrap, background: '#e8e0d8', animation: 'shimmer 1.4s infinite' }} />
    <div style={cardStyles.body}>
      {[90, 60, 40].map((w, i) => (
        <div key={i} style={{
          height: 12, width: `${w}%`, borderRadius: 4, marginBottom: 8,
          background: 'linear-gradient(90deg,#ede8e2 25%,#f8f3ee 50%,#ede8e2 75%)',
          backgroundSize: '200% 100%', animation: 'shimmer 1.4s infinite'
        }} />
      ))}
    </div>
  </div>
);

const PAGE_SIZE = 12;

const SearchPage = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const query = searchParams.get('q') || '';

  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [totalElements, setTotalElements] = useState(0);
  const [localQuery, setLocalQuery] = useState(query);

  useEffect(() => {
    setLocalQuery(query);
    setPage(0);
  }, [query]);

  useEffect(() => {
    if (!query.trim()) return;
    const fetch = async () => {
      setLoading(true);
      try {
        const res = await apiClient.get('/books/search', {
          params: { q: query, page, size: PAGE_SIZE },
        });
        const data = res.data;
        setBooks(data.content ?? data);
        setTotalPages(data.totalPages ?? 1);
        setTotalElements(data.totalElements ?? (data.content ?? data).length);
      } catch {
        setBooks([]);
      } finally {
        setLoading(false);
      }
    };
    fetch();
  }, [query, page]);

  const handleSearch = (e) => {
    e.preventDefault();
    if (localQuery.trim()) {
      setSearchParams({ q: localQuery.trim() });
    }
  };

  const goToBook = (book) => {
    navigate(`/books/${book.id ?? book.Id}`);
  };

  return (
    <>
      <style>{`
        @keyframes shimmer { to { background-position: -200% 0; } }
        @media (max-width: 640px) {
          .sp-page-inner { padding: 1rem 0.9rem 3rem !important; }
          .sp-topbar { gap: 0.5rem !important; }
          .sp-submit-text { display: none; }
          .sp-grid { grid-template-columns: repeat(2, 1fr) !important; gap: 0.75rem !important; }
          .sp-pagination { margin-top: 2rem !important; gap: 0.4rem !important; }
        }
        @media (max-width: 380px) {
          .sp-grid { grid-template-columns: repeat(2, 1fr) !important; }
        }
        .sp-card:hover .sp-overlay { opacity: 1 !important; }
        .sp-page:not(:disabled):hover { background: #F5C518 !important; color: #1a1008 !important; }
        .sp-submit:hover { background: #F5C518 !important; color: #1a1008 !important; }
      `}</style>

      <div style={pageStyles.page} className="sp-page-inner">

        {/* ── Top search bar ── */}
        <div style={pageStyles.topBar} className="sp-topbar">
          <button onClick={() => navigate(-1)} style={pageStyles.backBtn} aria-label="Go back">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" strokeWidth="2.5">
              <path d="M19 12H5M12 5l-7 7 7 7" />
            </svg>
          </button>
          <form onSubmit={handleSearch} style={pageStyles.form}>
            <input
              value={localQuery}
              onChange={(e) => setLocalQuery(e.target.value)}
              style={pageStyles.input}
              placeholder="Search books, authors…"
              autoFocus
            />
            <button type="submit" className="sp-submit" style={pageStyles.submitBtn}>
              Search
            </button>
          </form>
        </div>

        {/* ── Results header ── */}
        {query && (
          <div style={pageStyles.resultsHeader}>
            {loading ? (
              <span style={pageStyles.countText}>Searching…</span>
            ) : (
              <span style={pageStyles.countText}>
                <strong>{totalElements}</strong> result{totalElements !== 1 ? 's' : ''} for{' '}
                <span style={{ color: '#c0392b' }}>"{query}"</span>
              </span>
            )}
          </div>
        )}

        {/* ── Empty states ── */}
        {!loading && books.length === 0 && query && (
          <div style={pageStyles.emptyState}>
            <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>🔍</div>
            <p style={{ fontSize: '1.1rem', color: '#1a1008', fontWeight: 600 }}>
              "{query}" ke liye koi book nahi mili
            </p>
            <p style={{ color: '#8a7060', marginTop: '0.5rem' }}>
              Spelling check karo ya kuch aur try karo
            </p>
          </div>
        )}
        {!query && (
          <div style={pageStyles.emptyState}>
            <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>📚</div>
            <p style={{ color: '#8a7060' }}>Kuch search karo upar se</p>
          </div>
        )}

        {/* ── Grid ── */}
        <div style={pageStyles.grid} className="sp-grid">
          {loading
            ? Array.from({ length: PAGE_SIZE }).map((_, i) => <SkeletonCard key={i} />)
            : books.map((book, i) => (
                <BookCard
                  key={book.id ?? book.Id ?? i}
                  book={book}
                  onClick={() => goToBook(book)}
                />
              ))
          }
        </div>

        {/* ── Pagination ── */}
        {!loading && totalPages > 1 && (
          <div style={pageStyles.pagination} className="sp-pagination">
            <button
              className="sp-page"
              style={{ ...pageStyles.pageBtn, opacity: page === 0 ? 0.35 : 1 }}
              disabled={page === 0}
              onClick={() => setPage(p => p - 1)}
            >← Prev</button>

            {Array.from({ length: totalPages }, (_, i) => i)
              .filter(i => Math.abs(i - page) <= 2)
              .map(i => (
                <button
                  key={i}
                  className="sp-page"
                  style={{
                    ...pageStyles.pageBtn,
                    background: i === page ? '#F5C518' : 'white',
                    color: i === page ? '#1a1008' : '#8a7060',
                    fontWeight: i === page ? 700 : 400,
                  }}
                  onClick={() => setPage(i)}
                >{i + 1}</button>
              ))}

            <button
              className="sp-page"
              style={{ ...pageStyles.pageBtn, opacity: page >= totalPages - 1 ? 0.35 : 1 }}
              disabled={page >= totalPages - 1}
              onClick={() => setPage(p => p + 1)}
            >Next →</button>
          </div>
        )}
      </div>
    </>
  );
};

// ── Styles ──────────────────────────────────────────────────────
const pageStyles = {
  page: { maxWidth: 1280, margin: '0 auto', padding: '1.5rem 1.25rem 4rem' },
  topBar: { display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1.5rem' },
  backBtn: {
    background: '#1a1008', border: 'none', color: '#F5C518',
    width: 40, height: 40, borderRadius: '50%',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    cursor: 'pointer', flexShrink: 0, transition: 'background .2s',
  },
  form: { display: 'flex', flex: 1, gap: '0.5rem' },
  input: {
    flex: 1, border: '2px solid #1a1008', borderRadius: '8px',
    padding: '0.6rem 1rem', fontSize: '0.95rem',
    fontFamily: 'Inter, sans-serif', outline: 'none',
  },
  submitBtn: {
    background: '#1a1008', color: '#F5C518',
    border: 'none', borderRadius: '8px',
    padding: '0 1.5rem', fontWeight: 700, fontSize: '0.9rem',
    cursor: 'pointer', transition: 'background .2s, color .2s',
  },
  resultsHeader: { marginBottom: '1.25rem' },
  countText: { fontSize: '0.95rem', color: '#8a7060' },
  grid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(155px, 1fr))',
    gap: '1.25rem',
  },
  emptyState: { textAlign: 'center', padding: '5rem 2rem', color: '#8a7060' },
  pagination: {
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    gap: '0.5rem', marginTop: '3rem', flexWrap: 'wrap',
  },
  pageBtn: {
    padding: '0.5rem 1rem', border: '1.5px solid #e8e0d8',
    borderRadius: '6px', fontFamily: 'Inter, sans-serif',
    fontSize: '0.88rem', cursor: 'pointer',
    transition: 'background 0.2s, color 0.2s',
    background: 'white', color: '#8a7060',
  },
};

const cardStyles = {
  card: {
    background: 'white', borderRadius: 10,
    border: '1px solid #f0e8de', overflow: 'hidden',
    cursor: 'pointer',
    transition: 'transform .25s, box-shadow .25s',
  },
  imgWrap: {
    position: 'relative', aspectRatio: '3/4',
    background: '#f5ebe0', overflow: 'hidden',
  },
  img: { width: '100%', height: '100%', objectFit: 'cover', display: 'block' },
  placeholder: {
    width: '100%', height: '100%', display: 'flex',
    alignItems: 'center', justifyContent: 'center',
    background: 'linear-gradient(135deg,#2a1f14,#4a3525)',
  },
  badge: {
    position: 'absolute', top: 8, left: 8,
    background: '#E63946', color: '#fff',
    fontSize: '0.7rem', fontWeight: 700,
    padding: '3px 7px', borderRadius: 4,
    zIndex: 2,
  },
  // Dark hover overlay on image
  overlay: {
    position: 'absolute', inset: 0,
    background: 'rgba(26,16,8,0.55)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    opacity: 0, transition: 'opacity .2s',
    className: 'sp-overlay',
  },
  overlayText: {
    color: '#F5C518', fontWeight: 700,
    fontSize: '0.88rem', letterSpacing: '0.3px',
  },
  body: { padding: '0.85rem' },
  title: {
    fontWeight: 700, fontSize: '0.9rem', color: '#1a1008',
    marginBottom: 2, lineHeight: 1.3,
    display: '-webkit-box', WebkitLineClamp: 2,
    WebkitBoxOrient: 'vertical', overflow: 'hidden',
  },
  author: { fontSize: '0.75rem', color: '#8a7060', marginBottom: '0.6rem' },
  priceRow: {
    display: 'flex', alignItems: 'baseline',
    gap: '0.5rem', marginBottom: '0.7rem',
  },
  sellPrice: { fontSize: '1rem', fontWeight: 700, color: '#E63946' },
  origPrice: { fontSize: '0.78rem', color: '#aaa', textDecoration: 'line-through' },
  btn: {
    width: '100%', padding: '0.45rem',
    background: '#F5C518', color: '#1a1008',
    border: 'none', borderRadius: 6,
    fontSize: '0.8rem', fontWeight: 700, cursor: 'pointer',
    transition: 'background .15s',
  },
};

export default SearchPage;