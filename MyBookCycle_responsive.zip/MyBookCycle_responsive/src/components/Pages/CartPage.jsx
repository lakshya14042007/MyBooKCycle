import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import apiClient from '../../api/axiosConfig';

const CartPage = () => {
  const [items, setItems]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState(null); // cartItemId being updated
  const navigate = useNavigate();

  const fetchCart = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiClient.get('/cart');
      setItems(res.data);
    } catch {
      setItems([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchCart(); }, [fetchCart]);

  const updateQty = async (cartItemId, newQty) => {
    setUpdating(cartItemId);
    try {
      if (newQty <= 0) {
        await apiClient.delete(`/cart/remove/${cartItemId}`);
        setItems(prev => prev.filter(i => i.id !== cartItemId));
      } else {
        const res = await apiClient.put(`/cart/update/${cartItemId}`, { quantity: newQty });
        setItems(prev => prev.map(i => i.id === cartItemId ? res.data : i));
      }
    } finally {
      setUpdating(null);
    }
  };

  const clearCart = async () => {
    if (!window.confirm('Saara cart clear karna hai?')) return;
    await apiClient.delete('/cart/clear');
    setItems([]);
  };

  const total = items.reduce((sum, i) => {
    const price = i.book?.Selling_price ?? 0;
    return sum + price * i.quantity;
  }, 0);

  const totalOriginal = items.reduce((sum, i) => {
    const price = i.book?.Original_price ?? 0;
    return sum + price * i.quantity;
  }, 0);

  const savings = totalOriginal - total;

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        .cart-page * { font-family: 'Inter', sans-serif; box-sizing: border-box; }
        .cart-item-row { transition: background .15s; }
        .cart-item-row:hover { background: #fffbf0 !important; }
        .qty-btn:hover { background: #1a1008 !important; color: #F5C518 !important; }
        .remove-btn:hover { color: #E63946 !important; }
        .checkout-btn:hover { background: #e6b800 !important; transform: translateY(-1px); }
        .clear-btn:hover { color: #E63946 !important; border-color: #E63946 !important; }
        @keyframes shimmer { to { background-position: -200% 0; } }
        @media (max-width: 640px) {
          .cart-layout { flex-direction: column !important; }
          .cart-summary { width: 100% !important; position: static !important; }
          .cart-page-inner { padding: 1rem 0.9rem 3rem !important; }
          .cart-item-row-inner { flex-wrap: wrap !important; gap: 0.75rem !important; }
          .cart-title { font-size: 1.3rem !important; }
        }
        @media (max-width: 480px) {
          .cart-page-inner { padding: 0.75rem 0.75rem 3rem !important; }
          .cart-item-row-inner { padding: 0.85rem 0.5rem !important; }
        }
        .shimmer {
          background: linear-gradient(90deg,#ede8e2 25%,#f8f3ee 50%,#ede8e2 75%);
          background-size: 200% 100%; animation: shimmer 1.4s infinite; border-radius: 6px;
        }
      `}</style>

      <div className="cart-page cart-page-inner" style={S.page}>

        {/* Header */}
        <div style={S.header}>
          <button onClick={() => navigate(-1)} style={S.backBtn}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
              <path d="M19 12H5M12 5l-7 7 7 7"/>
            </svg>
          </button>
          <h1 style={S.title} className="cart-title">My Cart</h1>
          {items.length > 0 && (
            <button className="clear-btn" onClick={clearCart} style={S.clearBtn}>
              Clear all
            </button>
          )}
        </div>

        {/* Loading skeletons */}
        {loading && (
          <div style={S.layout} className="cart-layout">
            <div style={S.itemsCol}>
              {[1,2,3].map(i => (
                <div key={i} style={{ ...S.itemRow, gap: 16 }}>
                  <div className="shimmer" style={{ width: 80, height: 110, borderRadius: 8, flexShrink: 0 }}/>
                  <div style={{ flex: 1 }}>
                    <div className="shimmer" style={{ height: 14, width: '70%', marginBottom: 8 }}/>
                    <div className="shimmer" style={{ height: 12, width: '40%', marginBottom: 16 }}/>
                    <div className="shimmer" style={{ height: 32, width: 110 }}/>
                  </div>
                  <div className="shimmer" style={{ width: 60, height: 20 }}/>
                </div>
              ))}
            </div>
            <div className="shimmer" style={{ width: 300, height: 260, borderRadius: 12, flexShrink: 0 }}/>
          </div>
        )}

        {/* Empty state */}
        {!loading && items.length === 0 && (
          <div style={S.emptyState}>
            <div style={{ fontSize: '4rem', marginBottom: '1rem' }}>🛒</div>
            <p style={{ fontSize: '1.15rem', fontWeight: 600, color: '#1a1008' }}>
              Tumhara cart khali hai
            </p>
            <p style={{ color: '#8a7060', margin: '0.5rem 0 1.5rem' }}>
              Kuch books dhundho aur yahan add karo
            </p>
            <button onClick={() => navigate('/')} style={S.shopBtn}>
              Books Browse Karo
            </button>
          </div>
        )}

        {/* Cart items + summary */}
        {!loading && items.length > 0 && (
          <div style={S.layout} className="cart-layout">

            {/* Left: items */}
            <div style={S.itemsCol}>
              {items.map(item => {
                const book = item.book;
                const lineTotal = (book?.Selling_price ?? 0) * item.quantity;
                const isUpdating = updating === item.id;

                return (
                  <div key={item.id} className="cart-item-row cart-item-row-inner" style={S.itemRow}>

                    {/* Book image */}
                    <div style={S.imgWrap}>
                      {book?.image
                        ? <img src={book.image} alt={book.name} style={S.img}/>
                        : (
                          <div style={S.imgPlaceholder}>
                            <svg viewBox="0 0 60 80" width="40" fill="none">
                              <rect width="60" height="80" rx="4" fill="#2a1f14"/>
                              <rect x="4" y="0" width="4" height="80" rx="2" fill="#E63946" opacity=".7"/>
                              <rect x="10" y="12" width="38" height="3" rx="1.5" fill="#F5C518" opacity=".5"/>
                              <rect x="10" y="20" width="28" height="3" rx="1.5" fill="#F5C518" opacity=".3"/>
                            </svg>
                          </div>
                        )
                      }
                    </div>

                    {/* Book info */}
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={S.bookName}>{book?.name}</div>
                      <div style={S.bookAuthor}>by {book?.author}</div>

                      {/* Quantity controls */}
                      <div style={S.qtyRow}>
                        <button
                          className="qty-btn"
                          style={S.qtyBtn}
                          disabled={isUpdating}
                          onClick={() => updateQty(item.id, item.quantity - 1)}
                        >−</button>
                        <span style={S.qtyNum}>
                          {isUpdating ? '…' : item.quantity}
                        </span>
                        <button
                          className="qty-btn"
                          style={S.qtyBtn}
                          disabled={isUpdating}
                          onClick={() => updateQty(item.id, item.quantity + 1)}
                        >+</button>

                        <button
                          className="remove-btn"
                          style={S.removeBtn}
                          onClick={() => updateQty(item.id, 0)}
                        >
                          <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                            stroke="currentColor" strokeWidth="2">
                            <polyline points="3 6 5 6 21 6"/>
                            <path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/>
                            <path d="M10 11v6M14 11v6"/>
                            <path d="M9 6V4a1 1 0 011-1h4a1 1 0 011 1v2"/>
                          </svg>
                          Remove
                        </button>
                      </div>
                    </div>

                    {/* Price */}
                    <div style={{ textAlign: 'right', flexShrink: 0 }}>
                      <div style={S.linePrice}>₹{lineTotal.toFixed(0)}</div>
                      <div style={S.perUnit}>₹{book?.Selling_price} each</div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Right: order summary */}
            <div style={S.summary} className="cart-summary">
              <h2 style={S.summaryTitle}>Order Summary</h2>

              <div style={S.summaryRow}>
                <span>Books ({items.reduce((s,i) => s + i.quantity, 0)})</span>
                <span>₹{totalOriginal.toFixed(0)}</span>
              </div>
              {savings > 0 && (
                <div style={{ ...S.summaryRow, color: '#2a6049' }}>
                  <span>Your savings</span>
                  <span>− ₹{savings.toFixed(0)}</span>
                </div>
              )}
              <div style={S.summaryRow}>
                <span>Delivery</span>
                <span style={{ color: '#2a6049', fontWeight: 600 }}>FREE</span>
              </div>

              <div style={S.divider}/>

              <div style={S.totalRow}>
                <span>Total</span>
                <span>₹{total.toFixed(0)}</span>
              </div>

              {savings > 0 && (
                <div style={S.savingsBadge}>
                  🎉 You're saving ₹{savings.toFixed(0)} on this order!
                </div>
              )}

              <button className="checkout-btn" style={S.checkoutBtn}>
                Proceed to Checkout
              </button>

              <button onClick={() => navigate('/')} style={S.continueBtn}>
                ← Continue Shopping
              </button>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

// ── Styles ──────────────────────────────────────────────────────
const S = {
  page: { maxWidth: 1200, margin: '0 auto', padding: '1.5rem 1.25rem 4rem', minHeight: '60vh' },
  header: { display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '2rem' },
  backBtn: {
    background: '#1a1008', border: 'none', color: '#F5C518',
    width: 38, height: 38, borderRadius: '50%',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    cursor: 'pointer', flexShrink: 0,
  },
  title: { fontSize: '1.6rem', fontWeight: 700, color: '#1a1008', flex: 1 },
  clearBtn: {
    background: 'none', border: '1.5px solid #ccc', color: '#8a7060',
    padding: '6px 14px', borderRadius: 6, fontSize: '0.82rem',
    cursor: 'pointer', transition: 'color .2s, border-color .2s',
  },

  layout: { display: 'flex', gap: '2rem', alignItems: 'flex-start', flexWrap: 'wrap' },
  itemsCol: { flex: 1, minWidth: 300, display: 'flex', flexDirection: 'column', gap: '1px' },

  itemRow: {
    display: 'flex', gap: '1rem', alignItems: 'center',
    padding: '1.1rem 0.75rem', background: 'white',
    borderBottom: '1px solid #f0e8de', borderRadius: 4,
  },
  imgWrap: { width: 80, height: 110, borderRadius: 8, overflow: 'hidden', flexShrink: 0 },
  img: { width: '100%', height: '100%', objectFit: 'cover' },
  imgPlaceholder: {
    width: '100%', height: '100%', display: 'flex',
    alignItems: 'center', justifyContent: 'center',
    background: 'linear-gradient(135deg,#2a1f14,#4a3525)',
  },
  bookName: { fontWeight: 700, fontSize: '0.95rem', color: '#1a1008', marginBottom: 2 },
  bookAuthor: { fontSize: '0.78rem', color: '#8a7060', marginBottom: '0.65rem' },

  qtyRow: { display: 'flex', alignItems: 'center', gap: '0.5rem' },
  qtyBtn: {
    width: 30, height: 30, border: '1.5px solid #e0d8ce',
    background: 'white', borderRadius: 6, cursor: 'pointer',
    fontWeight: 700, fontSize: '1rem', color: '#1a1008',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    transition: 'background .15s, color .15s',
  },
  qtyNum: { minWidth: 24, textAlign: 'center', fontWeight: 700, fontSize: '0.95rem' },
  removeBtn: {
    display: 'flex', alignItems: 'center', gap: 4,
    background: 'none', border: 'none', color: '#aaa',
    fontSize: '0.78rem', cursor: 'pointer',
    marginLeft: '0.5rem', transition: 'color .15s',
  },

  linePrice: { fontSize: '1.05rem', fontWeight: 700, color: '#E63946' },
  perUnit: { fontSize: '0.72rem', color: '#aaa' },

  // Summary card
  summary: {
    width: 'min(300px, 100%)', flexShrink: 0, background: 'white',
    border: '1px solid #f0e8de', borderRadius: 12,
    padding: '1.5rem', position: 'sticky', top: 80,
  },
  summaryTitle: { fontSize: '1.1rem', fontWeight: 700, color: '#1a1008', marginBottom: '1.25rem' },
  summaryRow: {
    display: 'flex', justifyContent: 'space-between',
    fontSize: '0.88rem', color: '#5a4a3a', marginBottom: '0.65rem',
  },
  divider: { borderTop: '1px solid #f0e8de', margin: '1rem 0' },
  totalRow: {
    display: 'flex', justifyContent: 'space-between',
    fontWeight: 700, fontSize: '1.1rem', color: '#1a1008', marginBottom: '1rem',
  },
  savingsBadge: {
    background: '#f0faf4', color: '#2a6049',
    fontSize: '0.78rem', fontWeight: 600,
    padding: '8px 12px', borderRadius: 8,
    marginBottom: '1rem', textAlign: 'center',
  },
  checkoutBtn: {
    width: '100%', padding: '0.75rem',
    background: '#F5C518', color: '#1a1008',
    border: 'none', borderRadius: 8,
    fontWeight: 700, fontSize: '0.95rem',
    cursor: 'pointer', transition: 'background .2s, transform .15s',
    marginBottom: '0.75rem',
  },
  continueBtn: {
    width: '100%', padding: '0.6rem',
    background: 'none', color: '#8a7060',
    border: 'none', fontSize: '0.85rem',
    cursor: 'pointer', textAlign: 'center',
  },

  // Empty / shop
  emptyState: { textAlign: 'center', padding: '5rem 2rem' },
  shopBtn: {
    background: '#1a1008', color: '#F5C518',
    border: 'none', borderRadius: 8,
    padding: '0.7rem 1.75rem',
    fontWeight: 700, fontSize: '0.95rem', cursor: 'pointer',
  },
};

export default CartPage;
