import React, { useState, useEffect, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import apiClient from '../../api/axiosConfig';
import { AuthContext } from '../../context/AuthContext';

const AccountPage = () => {
  const { logout } = useContext(AuthContext);
  const navigate = useNavigate();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const res = await apiClient.get('/auth/profile');
        setProfile(res.data);
      } catch {
        // Fallback: decode JWT locally for basic info
        const token = localStorage.getItem('token');
        if (token) {
          try {
            const payload = JSON.parse(atob(token.split('.')[1]));
            setProfile({ email: payload.sub, name: payload.sub.split('@')[0] });
          } catch {
            setProfile(null);
          }
        }
      } finally {
        setLoading(false);
      }
    };
    fetchProfile();
  }, []);

  const handleLogout = () => {
    logout();
    navigate('/login', { replace: true });
  };

  const initials = profile?.name
    ? profile.name.slice(0, 2).toUpperCase()
    : profile?.email?.slice(0, 2).toUpperCase() ?? '??';

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        .acc-page * { font-family: 'Inter', sans-serif; box-sizing: border-box; }
        .acc-card { transition: box-shadow .2s; }
        .acc-card:hover { box-shadow: 0 4px 20px #1a100812 !important; }
        .logout-btn:hover { background: #E63946 !important; }
        @keyframes shimmer { to { background-position: -200% 0; } }
        @media (max-width: 480px) {
          .acc-page-inner { padding: 1rem 0.85rem 3rem !important; }
          .acc-card-inner { padding: 1.25rem !important; }
          .acc-avatar { width: 56px !important; height: 56px !important; font-size: 1.2rem !important; }
          .acc-profile-name { font-size: 1.05rem !important; }
          .acc-title { font-size: 1.25rem !important; }
        }
        .shimmer {
          background: linear-gradient(90deg,#ede8e2 25%,#f8f3ee 50%,#ede8e2 75%);
          background-size: 200% 100%; animation: shimmer 1.4s infinite; border-radius: 6px;
        }
      `}</style>

      <div className="acc-page acc-page-inner" style={S.page}>

        {/* Header */}
        <div style={S.header}>
          <button onClick={() => navigate(-1)} style={S.backBtn}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
              <path d="M19 12H5M12 5l-7 7 7 7"/>
            </svg>
          </button>
          <h1 style={S.title} className="acc-title">My Account</h1>
        </div>

        {/* Loading */}
        {loading && (
          <div style={S.card}>
            <div style={{ display: 'flex', gap: '1.5rem', alignItems: 'center', marginBottom: '2rem' }}>
              <div className="shimmer" style={{ width: 80, height: 80, borderRadius: '50%' }}/>
              <div>
                <div className="shimmer" style={{ width: 160, height: 18, marginBottom: 10 }}/>
                <div className="shimmer" style={{ width: 220, height: 14 }}/>
              </div>
            </div>
          </div>
        )}

        {/* Profile card */}
        {!loading && profile && (
          <div style={S.card} className="acc-card acc-card-inner">

            {/* Avatar + name */}
            <div style={S.profileTop}>
              <div style={S.avatar} className="acc-avatar">{initials}</div>
              <div>
                <div style={S.profileName} className="acc-profile-name">
                  {profile.name || profile.email.split('@')[0]}
                </div>
                <div style={S.profileTag}>MyBookCycle Member</div>
              </div>
            </div>

            <div style={S.divider}/>

            {/* Info rows */}
            <div style={S.infoGrid}>
              <InfoRow
                icon={
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                    stroke="#8a7060" strokeWidth="2">
                    <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                    <polyline points="22,6 12,13 2,6"/>
                  </svg>
                }
                label="Email"
                value={profile.email}
              />
              {profile.name && profile.name !== profile.email.split('@')[0] && (
                <InfoRow
                  icon={
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                      stroke="#8a7060" strokeWidth="2">
                      <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/>
                      <circle cx="12" cy="7" r="4"/>
                    </svg>
                  }
                  label="Name"
                  value={profile.name}
                />
              )}
              {profile.phone && (
                <InfoRow
                  icon={
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                      stroke="#8a7060" strokeWidth="2">
                      <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81 19.79 19.79 0 01.08 1.2 2 2 0 012.08 0h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.09 7.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z"/>
                    </svg>
                  }
                  label="Phone"
                  value={profile.phone}
                />
              )}
            </div>

            <div style={S.divider}/>

            {/* Quick links */}
            <div style={S.quickLinks}>
              <QuickLink
                icon="📚"
                label="My Listed Books"
                sub="Books you're selling"
                onClick={() => navigate('/my-books')}
              />
              <QuickLink
                icon="🛒"
                label="My Cart"
                sub="Items you've added"
                onClick={() => navigate('/cart')}
              />
            </div>

            <div style={S.divider}/>

            {/* Logout */}
            <button className="logout-btn" onClick={handleLogout} style={S.logoutBtn}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/>
                <polyline points="16 17 21 12 16 7"/>
                <line x1="21" y1="12" x2="9" y2="12"/>
              </svg>
              Logout
            </button>
          </div>
        )}

        {/* Not found */}
        {!loading && !profile && (
          <div style={{ textAlign: 'center', padding: '4rem', color: '#8a7060' }}>
            <p>Profile load nahi ho paya. Dobara login karo.</p>
            <button onClick={() => navigate('/login')} style={S.logoutBtn}>
              Go to Login
            </button>
          </div>
        )}
      </div>
    </>
  );
};

const InfoRow = ({ icon, label, value }) => (
  <div style={{
    display: 'flex', alignItems: 'center', gap: '0.75rem',
    padding: '0.7rem 0', borderBottom: '1px solid #f5f0ea',
  }}>
    <span style={{ flexShrink: 0 }}>{icon}</span>
    <div>
      <div style={{ fontSize: '0.72rem', color: '#8a7060', textTransform: 'uppercase',
        letterSpacing: '0.5px', fontWeight: 600 }}>{label}</div>
      <div style={{ fontSize: '0.92rem', color: '#1a1008', fontWeight: 500 }}>{value}</div>
    </div>
  </div>
);

const QuickLink = ({ icon, label, sub, onClick }) => (
  <div onClick={onClick} style={{
    display: 'flex', alignItems: 'center', gap: '1rem',
    padding: '0.85rem 0.5rem', cursor: 'pointer', borderRadius: 8,
    transition: 'background .15s',
  }}
  onMouseEnter={e => e.currentTarget.style.background = '#fffbf0'}
  onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
  >
    <span style={{ fontSize: '1.4rem' }}>{icon}</span>
    <div style={{ flex: 1 }}>
      <div style={{ fontWeight: 600, fontSize: '0.9rem', color: '#1a1008' }}>{label}</div>
      <div style={{ fontSize: '0.75rem', color: '#8a7060' }}>{sub}</div>
    </div>
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
      stroke="#ccc" strokeWidth="2"><path d="M9 18l6-6-6-6"/></svg>
  </div>
);

// ── Styles ──────────────────────────────────────────────────────
const S = {
  page: { maxWidth: 600, margin: '0 auto', padding: '1.5rem 1rem 4rem' },
  header: { display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '2rem' },
  backBtn: {
    background: '#1a1008', border: 'none', color: '#F5C518',
    width: 38, height: 38, borderRadius: '50%',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    cursor: 'pointer',
  },
  title: { fontSize: '1.5rem', fontWeight: 700, color: '#1a1008' },
  card: {
    background: 'white', borderRadius: 14,
    border: '1px solid #f0e8de', padding: '1.75rem',
    boxShadow: '0 2px 8px #1a10080a',
  },
  profileTop: { display: 'flex', alignItems: 'center', gap: '1.25rem', marginBottom: '1.5rem' },
  avatar: {
    width: 72, height: 72, borderRadius: '50%',
    background: '#1a1008', color: '#F5C518',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    fontSize: '1.5rem', fontWeight: 700, flexShrink: 0,
    border: '3px solid #F5C518',
  },
  profileName: { fontSize: '1.2rem', fontWeight: 700, color: '#1a1008' },
  profileTag: { fontSize: '0.78rem', color: '#8a7060', marginTop: 3 },
  divider: { borderTop: '1px solid #f0e8de', margin: '1.25rem 0' },
  infoGrid: { display: 'flex', flexDirection: 'column' },
  quickLinks: { display: 'flex', flexDirection: 'column' },
  logoutBtn: {
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    gap: '0.5rem', width: '100%',
    background: '#1a1008', color: 'white',
    border: 'none', borderRadius: 8,
    padding: '0.7rem', fontWeight: 700, fontSize: '0.9rem',
    cursor: 'pointer', transition: 'background .2s',
    marginTop: '0.5rem',
  },
};

export default AccountPage;
