import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import apiClient from '../../api/axiosConfig';

// ── Small card for similar books ─────────────────────────────────
const SimilarCard = ({ book, onClick }) => (
  <div onClick={onClick} style={SC.card}
    onMouseEnter={e => {
      e.currentTarget.style.transform = 'translateY(-5px)';
      e.currentTarget.style.boxShadow = '4px 10px 24px #1a100818';
    }}
    onMouseLeave={e => {
      e.currentTarget.style.transform = 'translateY(0)';
      e.currentTarget.style.boxShadow = '0 2px 8px #1a10080a';
    }}
  >
    <div style={SC.imgWrap}>
      {book.image ? (
        <img src={book.image} alt={book.name} style={SC.img} />
      ) : (
        <div style={SC.placeholder}>
          <svg viewBox="0 0 60 80" width="36" fill="none">
            <rect width="60" height="80" rx="4" fill="#2a1f14" />
            <rect x="4" y="0" width="4" height="80" rx="2" fill="#E63946" opacity=".7" />
            <rect x="10" y="14" width="36" height="3" rx="1.5" fill="#F5C518" opacity=".5" />
            <rect x="10" y="22" width="26" height="3" rx="1.5" fill="#F5C518" opacity=".3" />
          </svg>
        </div>
      )}
    </div>
    <div style={SC.body}>
      <div style={SC.name}>{book.name}</div>
      <div style={SC.price}>₹{book.Selling_price}</div>
    </div>
  </div>
);

const SC = {
  card: {
    background: 'white', borderRadius: 10, border: '1px solid #f0e8de',
    overflow: 'hidden', cursor: 'pointer',
    transition: 'transform .25s, box-shadow .25s',
    boxShadow: '0 2px 8px #1a10080a',
  },
  imgWrap: { aspectRatio: '3/4', background: '#f5ebe0', overflow: 'hidden' },
  img: { width: '100%', height: '100%', objectFit: 'cover', display: 'block' },
  placeholder: {
    width: '100%', height: '100%', display: 'flex',
    alignItems: 'center', justifyContent: 'center',
    background: 'linear-gradient(135deg,#2a1f14,#4a3525)',
  },
  body: { padding: '0.65rem' },
  name: {
    fontSize: '0.82rem', fontWeight: 700, color: '#1a1008',
    display: '-webkit-box', WebkitLineClamp: 2,
    WebkitBoxOrient: 'vertical', overflow: 'hidden',
    lineHeight: 1.3, marginBottom: 3,
  },
  price: { fontSize: '0.85rem', fontWeight: 700, color: '#E63946' },
};

// ── Skeleton for detail page ──────────────────────────────────────
const DetailSkeleton = () => (
  <div style={{ display: 'flex', gap: '3rem', flexWrap: 'wrap' }}>
    <style>{`@keyframes shimmer{to{background-position:-200% 0}}`}</style>
    <div style={{ width: 320, flexShrink: 0 }}>
      <div style={{
        aspectRatio: '3/4', borderRadius: 14,
        background: 'linear-gradient(90deg,#ede8e2 25%,#f8f3ee 50%,#ede8e2 75%)',
        backgroundSize: '200% 100%', animation: 'shimmer 1.4s infinite',
      }} />
    </div>
    <div style={{ flex: 1, minWidth: 280 }}>
      {[70, 45, 30, 30, 55, 55].map((w, i) => (
        <div key={i} style={{
          height: i === 0 ? 28 : 16, width: `${w}%`, borderRadius: 6,
          marginBottom: i === 0 ? 16 : 12,
          background: 'linear-gradient(90deg,#ede8e2 25%,#f8f3ee 50%,#ede8e2 75%)',
          backgroundSize: '200% 100%', animation: 'shimmer 1.4s infinite',
        }} />
      ))}
      <div style={{ display: 'flex', gap: 12, marginTop: 24 }}>
        <div style={{ flex: 1, height: 48, borderRadius: 8, background: '#ede8e2' }} />
        <div style={{ flex: 1, height: 48, borderRadius: 8, background: '#ede8e2' }} />
      </div>
    </div>
  </div>
);

// ── Main Page ─────────────────────────────────────────────────────
const BookDetailPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [book, setBook]           = useState(null);
  const [similar, setSimilar]     = useState([]);
  const [loading, setLoading]     = useState(true);
  const [cartLoading, setCartLoading] = useState(false);
  const [cartDone, setCartDone]   = useState(false);
  const [error, setError]         = useState(null);

  const fetchBook = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [bookRes, simRes] = await Promise.all([
        apiClient.get(`/books/${id}`),
        apiClient.get(`/books/${id}/similar`).catch(() => ({ data: [] })),
      ]);
      setBook(bookRes.data);
      setSimilar(simRes.data);
    } catch {
      setError('Book load nahi hui.');
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    window.scrollTo(0, 0);
    fetchBook();
    setCartDone(false);
  }, [id, fetchBook]);

  const handleAddToCart = async () => {
    setCartLoading(true);
    try {
      await apiClient.post(`/cart/add/${id}`);
      setCartDone(true);
      setTimeout(() => setCartDone(false), 2500);
    } catch (e) {
      if (e.response?.status === 401 || e.response?.status === 403) {
        navigate('/login');
      } else {
        alert('Cart mein add nahi hua, dobara try karo');
      }
    } finally {
      setCartLoading(false);
    }
  };

  const handleBuyNow = async () => {
    setCartLoading(true);
    try {
      await apiClient.post(`/cart/add/${id}`);
      navigate('/cart');
    } catch (e) {
      if (e.response?.status === 401 || e.response?.status === 403) {
        navigate('/login');
      } else {
        alert('Error hua, dobara try karo');
      }
    } finally {
      setCartLoading(false);
    }
  };

  const discount = book?.Original_price && book?.Selling_price
    ? Math.round(((book.Original_price - book.Selling_price) / book.Original_price) * 100)
    : null;

  const savings = book?.Original_price && book?.Selling_price
    ? (book.Original_price - book.Selling_price).toFixed(0)
    : null;

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=Inter:wght@400;500;600;700&display=swap');
        .bdp * { font-family: 'Inter', sans-serif; box-sizing: border-box; }
        @media (max-width: 640px) {
          .bdp-img-col { width: 100% !important; }
          .bdp-main { flex-direction: column !important; gap: 1.5rem !important; }
          .bdp-page { padding: 1rem 0.9rem 3rem !important; }
          .bdp-btn-row { flex-direction: column !important; }
          .bdp-btn-row button { min-width: unset !important; width: 100% !important; }
          .bdp-pills { gap: 0.5rem !important; }
          .bdp-sell-price { font-size: 1.6rem !important; }
          .bdp-similar-grid { grid-template-columns: repeat(auto-fill, minmax(120px, 1fr)) !important; gap: 0.75rem !important; }
        }
        @media (max-width: 480px) {
          .bdp-page { padding: 0.75rem 0.75rem 3rem !important; }
        }
        .cart-btn:hover:not(:disabled) { background: #e6b800 !important; transform: translateY(-1px); }
        .buy-btn:hover:not(:disabled)  { background: #c0392b !important; transform: translateY(-1px); }
        .back-btn:hover { background: #F5C518 !important; color: #1a1008 !important; }
        @keyframes shimmer { to { background-position: -200% 0; } }
        @keyframes pop { 0%{transform:scale(1)} 50%{transform:scale(1.08)} 100%{transform:scale(1)} }
      `}</style>

      <div className="bdp" style={S.page}>

        {/* ── Back button ── */}
        <button className="back-btn" onClick={() => navigate(-1)} style={S.backBtn}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
            stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
            <path d="M19 12H5M12 5l-7 7 7 7" />
          </svg>
          Back
        </button>

        {/* ── Error ── */}
        {error && (
          <div style={S.errorBox}>
            ⚠️ {error}
            <button onClick={fetchBook} style={S.retryBtn}>Retry</button>
          </div>
        )}

        {/* ── Loading skeleton ── */}
        {loading && <DetailSkeleton />}

        {/* ── Main content ── */}
        {!loading && book && (
          <>
            <div style={S.mainLayout} className="bdp-main">

              {/* Left: Book image */}
              <div style={S.imageCol} className="bdp-img-col">
                <div style={S.imgFrame}>
                  {book.image ? (
                    <img src={book.image} alt={book.name} style={S.img} />
                  ) : (
                    <div style={S.imgPlaceholder}>
                      <svg viewBox="0 0 80 110" width="100" fill="none">
                        <rect width="80" height="110" rx="6" fill="#2a1f14" />
                        <rect x="6" y="0" width="6" height="110" rx="3" fill="#E63946" opacity=".8" />
                        <rect x="16" y="18" width="52" height="5" rx="2.5" fill="#F5C518" opacity=".7" />
                        <rect x="16" y="30" width="40" height="4" rx="2" fill="#F5C518" opacity=".4" />
                        <rect x="16" y="40" width="48" height="4" rx="2" fill="#F5C518" opacity=".4" />
                        <rect x="16" y="50" width="34" height="4" rx="2" fill="#F5C518" opacity=".4" />
                      </svg>
                      <p style={{ color: '#c0a882', fontSize: '0.8rem', marginTop: 12 }}>
                        No cover image
                      </p>
                    </div>
                  )}
                  {/* Discount ribbon */}
                  {discount > 0 && (
                    <div style={S.ribbon}>
                      <span>{discount}% OFF</span>
                    </div>
                  )}
                </div>

                {/* Savings badge */}
                {savings > 0 && (
                  <div style={S.savingsBadge}>
                    🎉 You save ₹{savings} on this book!
                  </div>
                )}
              </div>

              {/* Right: Details */}
              <div style={S.detailCol}>

                {/* Status */}
                <span style={{
                  ...S.statusChip,
                  background: book.status?.toLowerCase() === 'sold'
                    ? '#E63946' : '#2a6049',
                }}>
                  {book.status || 'Available'}
                </span>

                {/* Title */}
                <h1 style={S.title}>{book.name}</h1>
                <p style={S.author}>by <strong>{book.author}</strong></p>

                {/* Divider */}
                <div style={S.divider} />

                {/* Price section */}
                <div style={S.priceSection} className="bdp-price">
                  <div style={S.sellPrice} className="bdp-sell-price">₹{book.Selling_price}</div>
                  {book.Original_price && (
                    <div style={S.origPrice}>
                      MRP: <span style={{ textDecoration: 'line-through' }}>
                        ₹{book.Original_price}
                      </span>
                    </div>
                  )}
                  {discount > 0 && (
                    <div style={S.discountTag}>{discount}% off</div>
                  )}
                </div>

                <div style={S.divider} />

                {/* Info pills */}
                <div style={S.infoPills} className="bdp-pills">
                  <InfoPill icon="📦" label="Condition" value={book.status || 'Good'} />
                  <InfoPill icon="🚚" label="Delivery" value="Free" />
                  <InfoPill icon="↩️" label="Returns" value="7 days" />
                </div>

                <div style={S.divider} />

                {/* Action buttons */}
                {book.status?.toLowerCase() !== 'sold' ? (
                  <div style={S.btnRow} className="bdp-btn-row">
                    <button
                      className="cart-btn"
                      style={{
                        ...S.cartBtn,
                        background: cartDone ? '#2a6049' : '#F5C518',
                        color: cartDone ? '#fff' : '#1a1008',
                        animation: cartDone ? 'pop .3s ease' : 'none',
                      }}
                      onClick={handleAddToCart}
                      disabled={cartLoading}
                    >
                      {cartLoading ? (
                        <span style={S.spinner} />
                      ) : cartDone ? (
                        '✓ Added to Cart!'
                      ) : (
                        <>
                          <svg width="18" height="18" viewBox="0 0 24 24" fill="none"
                            stroke="currentColor" strokeWidth="2">
                            <circle cx="9" cy="21" r="1" /><circle cx="20" cy="21" r="1" />
                            <path d="M1 1h4l2.68 13.39a2 2 0 002 1.61h9.72a2 2 0 002-1.61L23 6H6" />
                          </svg>
                          Add to Cart
                        </>
                      )}
                    </button>

                    <button
                      className="buy-btn"
                      style={S.buyBtn}
                      onClick={handleBuyNow}
                      disabled={cartLoading}
                    >
                      {cartLoading ? <span style={S.spinner} /> : 'Buy Now →'}
                    </button>
                  </div>
                ) : (
                  <div style={S.soldNotice}>
                    😔 Yeh book sold ho chuki hai
                  </div>
                )}
              </div>
            </div>

            {/* ── Similar Books ── */}
            {similar.length > 0 && (
              <div style={S.similarSection}>
                <div style={S.similarHeader}>
                  <h2 style={S.similarTitle}>
                    More by <span style={{ color: '#E63946' }}>{book.author}</span>
                  </h2>
                  <div style={S.similarLine} />
                </div>
                <div style={S.similarGrid} className="bdp-similar-grid">
                  {similar.map(b => (
                    <SimilarCard
                      key={b.id ?? b.Id}
                      book={b}
                      onClick={() => navigate(`/books/${b.id ?? b.Id}`)}
                    />
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </>
  );
};

// ── Info Pill ────────────────────────────────────────────────────
const InfoPill = ({ icon, label, value }) => (
  <div style={{
    display: 'flex', flexDirection: 'column', alignItems: 'center',
    background: '#fffbf0', border: '1px solid #f0e8de',
    borderRadius: 10, padding: '0.65rem 1rem', flex: 1, minWidth: 80,
  }}>
    <span style={{ fontSize: '1.2rem', marginBottom: 4 }}>{icon}</span>
    <span style={{ fontSize: '0.68rem', color: '#8a7060', fontWeight: 600,
      textTransform: 'uppercase', letterSpacing: '0.5px' }}>{label}</span>
    <span style={{ fontSize: '0.82rem', color: '#1a1008', fontWeight: 700, marginTop: 2 }}>
      {value}
    </span>
  </div>
);

// ── Styles ───────────────────────────────────────────────────────
const S = {
  page: { maxWidth: 1200, margin: '0 auto', padding: '1.5rem 1.25rem 4rem' },

  backBtn: {
    display: 'inline-flex', alignItems: 'center', gap: 6,
    background: '#1a1008', color: '#F5C518',
    border: 'none', borderRadius: 8,
    padding: '0.5rem 1rem', fontSize: '0.85rem',
    fontWeight: 600, cursor: 'pointer',
    marginBottom: '2rem',
    transition: 'background .2s, color .2s',
  },

  errorBox: {
    display: 'flex', alignItems: 'center', gap: '1rem',
    background: '#fff0f0', border: '1px solid #ffcccc',
    borderRadius: 8, padding: '1rem 1.25rem',
    color: '#E63946', marginBottom: '1.5rem',
  },
  retryBtn: {
    background: '#1a1008', color: '#F5C518', border: 'none',
    borderRadius: 6, padding: '0.4rem 1rem',
    fontSize: '0.82rem', fontWeight: 600, cursor: 'pointer',
  },

  mainLayout: {
    display: 'flex', gap: '2rem', alignItems: 'flex-start', flexWrap: 'wrap',
    marginBottom: '3rem',
  },

  // Image column
  imageCol: { width: 'min(320px, 100%)', flexShrink: 0 },
  imgFrame: {
    position: 'relative', borderRadius: 14, overflow: 'hidden',
    boxShadow: '0 8px 40px #1a100828',
    aspectRatio: '3/4', background: '#f5ebe0',
  },
  img: { width: '100%', height: '100%', objectFit: 'cover', display: 'block' },
  imgPlaceholder: {
    width: '100%', height: '100%', display: 'flex',
    flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
    background: 'linear-gradient(135deg,#2a1f14,#4a3525)',
  },
  ribbon: {
    position: 'absolute', top: 18, right: -28,
    background: '#E63946', color: '#fff',
    fontSize: '0.72rem', fontWeight: 800,
    padding: '5px 36px', transform: 'rotate(45deg)',
    letterSpacing: '0.5px',
  },
  savingsBadge: {
    marginTop: '0.85rem', background: '#f0faf4',
    color: '#2a6049', border: '1px solid #c3e6cb',
    borderRadius: 8, padding: '0.6rem 1rem',
    fontSize: '0.82rem', fontWeight: 600, textAlign: 'center',
  },

  // Detail column
  detailCol: { flex: 1, minWidth: 280 },
  statusChip: {
    display: 'inline-block', color: '#fff',
    fontSize: '0.68rem', fontWeight: 700,
    textTransform: 'uppercase', letterSpacing: '1px',
    padding: '4px 10px', borderRadius: 20, marginBottom: '0.85rem',
  },
  title: {
    fontFamily: "'Playfair Display', serif",
    fontSize: 'clamp(1.6rem, 3vw, 2.2rem)',
    fontWeight: 900, color: '#1a1008',
    lineHeight: 1.2, margin: '0 0 0.4rem',
  },
  author: { fontSize: '1rem', color: '#8a7060', margin: '0 0 1rem' },
  divider: { borderTop: '1px solid #f0e8de', margin: '1.1rem 0' },

  priceSection: { display: 'flex', alignItems: 'center', gap: '0.85rem', flexWrap: 'wrap' },
  sellPrice: {
    fontSize: '2rem', fontWeight: 800, color: '#E63946',
    fontFamily: "'Inter', sans-serif",
  },
  origPrice: { fontSize: '0.9rem', color: '#aaa' },
  discountTag: {
    background: '#fff0f0', color: '#E63946',
    fontSize: '0.82rem', fontWeight: 700,
    padding: '4px 10px', borderRadius: 6,
  },

  infoPills: { display: 'flex', gap: '0.75rem', flexWrap: 'wrap' },

  btnRow: { display: 'flex', gap: '1rem', flexWrap: 'wrap' },
  cartBtn: {
    flex: 1, minWidth: 140, padding: '0.85rem 1rem',
    border: 'none', borderRadius: 10,
    fontSize: '0.95rem', fontWeight: 700, cursor: 'pointer',
    display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7,
    transition: 'background .2s, transform .15s, color .2s',
  },
  buyBtn: {
    flex: 1, minWidth: 140, padding: '0.85rem 1rem',
    background: '#E63946', color: '#fff',
    border: 'none', borderRadius: 10,
    fontSize: '0.95rem', fontWeight: 700, cursor: 'pointer',
    transition: 'background .2s, transform .15s',
  },
  soldNotice: {
    background: '#fff0f0', color: '#E63946',
    border: '1.5px solid #ffcccc',
    borderRadius: 10, padding: '1rem',
    fontSize: '0.95rem', fontWeight: 600, textAlign: 'center',
  },
  spinner: {
    display: 'inline-block', width: 18, height: 18,
    border: '3px solid rgba(0,0,0,0.15)',
    borderTop: '3px solid currentColor',
    borderRadius: '50%', animation: 'spin .7s linear infinite',
  },

  // Similar section
  similarSection: { marginTop: '1rem' },
  similarHeader: { display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1.25rem' },
  similarTitle: {
    fontFamily: "'Playfair Display', serif",
    fontSize: '1.35rem', fontWeight: 700, color: '#1a1008',
    flexShrink: 0, margin: 0,
  },
  similarLine: { flex: 1, height: 1, background: '#f0e8de' },
  similarGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))',
    gap: '1rem',
  },
};

export default BookDetailPage;
