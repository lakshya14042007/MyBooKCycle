import { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom"; // ← ADD
import apiClient from "../../api/axiosConfig";

// ── Skeleton loader ──────────────────────────────────────────────
function SkeletonCard() {
  return (
    <div className="book-card skeleton">
      <div className="card-img-wrap skeleton-block" />
      <div className="card-body">
        <div className="skeleton-line wide" />
        <div className="skeleton-line mid" />
        <div className="skeleton-line narrow" />
        <div className="skeleton-price-row">
          <div className="skeleton-line price" />
          <div className="skeleton-line price" />
        </div>
      </div>
    </div>
  );
}

// ── Book Card ────────────────────────────────────────────────────
function BookCard({ book }) {
  const navigate = useNavigate(); // ← MOVED INSIDE COMPONENT

  const discount = book.Original_price && book.Selling_price
    ? Math.round(((book.Original_price - book.Selling_price) / book.Original_price) * 100)
    : null;

  const handleAddToCart = async (e) => {
    e.stopPropagation(); // card click se alag rakho
    try {
      await apiClient.post(`/cart/add/${book.id ?? book.Id}`);
      alert('Cart mein add ho gaya! 🛒');
    } catch {
      alert('Pehle login karo');
    }
  };

  return (
    <div className="book-card" onClick={() => navigate(`/books/${book.id ?? book.Id}`)}>
      <div className="card-img-wrap">
        {book.image ? (
          <img src={book.image} alt={book.name} className="card-img" />
        ) : (
          <div className="card-img-placeholder">
            <svg viewBox="0 0 60 80" fill="none">
              <rect width="60" height="80" rx="4" fill="#2a1f14"/>
              <rect x="6" y="10" width="48" height="4" rx="2" fill="#F5C518" opacity="0.6"/>
              <rect x="6" y="20" width="36" height="3" rx="1.5" fill="#F5C518" opacity="0.3"/>
              <rect x="6" y="28" width="42" height="3" rx="1.5" fill="#F5C518" opacity="0.3"/>
              <rect x="6" y="36" width="30" height="3" rx="1.5" fill="#F5C518" opacity="0.3"/>
              <rect x="4" y="0" width="4" height="80" rx="2" fill="#E63946" opacity="0.7"/>
            </svg>
          </div>
        )}
        {discount > 0 && (
          <span className="discount-badge">-{discount}%</span>
        )}
        <div className="status-chip" data-status={book.status?.toLowerCase()}>
          {book.status || "Available"}
        </div>
      </div>

      <div className="card-body">
        <h3 className="book-title">{book.name}</h3>
        <p className="book-author">by {book.author}</p>
        <div className="price-row">
          <span className="sell-price">
            ₹{book.Selling_price?.toFixed ? book.Selling_price.toFixed(0) : book.Selling_price}
          </span>
          {book.Original_price && (
            <span className="orig-price">
              ₹{book.Original_price?.toFixed ? book.Original_price.toFixed(0) : book.Original_price}
            </span>
          )}
        </div>
        <button className="add-cart-btn" onClick={handleAddToCart}>
          Add to Cart
        </button>
      </div>
    </div>
  );
}

// ── Main HomePage ────────────────────────────────────────────────
export default function HomePage() {
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const PAGE_SIZE = 12;

  const fetchBooks = useCallback(async (pageNum = 0) => {
    setLoading(true);
    setError(null);
    try {
      const res = await apiClient.get("/books", {
        params: { page: pageNum, size: PAGE_SIZE },
      });
      const data = res.data;
      setBooks(data.content ?? data);
      setTotalPages(data.totalPages ?? 1);
    } catch (err) {
      setError("Books can't load right now. Please try again later.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchBooks(page);
  }, [page, fetchBooks]);

  const filtered = books.filter((b) => {
    const q = search.toLowerCase();
    return (
      b.name?.toLowerCase().includes(q) ||
      b.author?.toLowerCase().includes(q)
    );
  });

  return (
    <>
      <style>{CSS}</style>

      {/* ── NAVBAR ── */}
      <nav className="navbar">
        <a href="/" className="logo">
          <span className="logo-book">📚</span>
          <span className="logo-text">MyBook<span className="logo-accent">Cycle</span></span>
        </a>
        <div className="nav-links">
          <a href="/" className="nav-link active">Home</a>
          <a href="/my-books" className="nav-link">Books on Sell</a>
          <a href="/orders" className="nav-link">Orders</a>
        </div>
        <div className="nav-actions">
          <a href="/cart" className="icon-btn" aria-label="Cart">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/>
              <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>
            </svg>
          </a>
          <a href="/account" className="icon-btn" aria-label="Profile">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
              <circle cx="12" cy="7" r="4"/>
            </svg>
          </a>
        </div>
      </nav>

      {/* ── HERO ── */}
      <section className="hero">
        <div className="hero-inner">
          <p className="hero-eyebrow">India's Second-Hand Book Bazaar</p>
          <h1 className="hero-headline">
            Purani kitaabein,<br />
            <span className="hero-accent">naye safar</span>
          </h1>
          <p className="hero-sub">Buy & sell pre-loved books at unbeatable prices</p>
          <div className="search-bar">
            <svg className="search-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
            </svg>
            <input
              type="text"
              placeholder="Search by title or author…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="search-input"
            />
            {search && (
              <button className="clear-btn" onClick={() => setSearch("")}>✕</button>
            )}
          </div>
        </div>
        <div className="hero-books-deco" aria-hidden>
          {["#E63946","#F5C518","#2a6049","#1a3a6b","#7b2d8b"].map((c, i) => (
            <div key={i} className="deco-book" style={{ "--c": c, "--delay": `${i * 0.15}s` }} />
          ))}
        </div>
      </section>

      {/* ── MAIN CONTENT ── */}
      <main className="main">
        <div className="section-header">
          <h2 className="section-title">
            {search ? `Results for "${search}"` : "Browse Books"}
          </h2>
          <span className="book-count">
            {loading ? "…" : `${filtered.length} book${filtered.length !== 1 ? "s" : ""}`}
          </span>
        </div>

        {error && (
          <div className="error-box">
            <span>⚠️ {error}</span>
            <button onClick={() => fetchBooks(page)} className="retry-btn">Retry</button>
          </div>
        )}

        <div className="books-grid">
          {loading
            ? Array.from({ length: PAGE_SIZE }).map((_, i) => <SkeletonCard key={i} />)
            : filtered.length > 0
              ? filtered.map((book) => <BookCard key={book.id ?? book.Id} book={book} />)
              : (
                <div className="empty-state">
                  <div className="empty-icon">📭</div>
                  <p>Books not found for "{search}"</p>
                  <button onClick={() => setSearch("")} className="retry-btn">Clear search</button>
                </div>
              )
          }
        </div>

        {/* ── PAGINATION ── */}
        {!loading && !search && totalPages > 1 && (
          <div className="pagination">
            <button
              className="page-btn"
              disabled={page === 0}
              onClick={() => setPage((p) => p - 1)}
            >← Prev</button>
            <span className="page-info">{page + 1} / {totalPages}</span>
            <button
              className="page-btn"
              disabled={page >= totalPages - 1}
              onClick={() => setPage((p) => p + 1)}
            >Next →</button>
          </div>
        )}
      </main>

      {/* ── FOOTER ── */}
      <footer className="footer">
        <p>© 2025 MyBookCycle — Kitaabein baanto, gyaan failaao 📚</p>
      </footer>
    </>
  );
}

// ── CSS ──────────────────────────────────────────────────────────
const CSS = `
  @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=Inter:wght@400;500;600&display=swap');

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --black:   #1A1008;
    --yellow:  #F5C518;
    --red:     #E63946;
    --cream:   #FFF8F0;
    --muted:   #8A7060;
    --card-bg: #ffffff;
    --border:  #F0E8DE;
    --radius:  10px;
  }

  body { background: var(--cream); color: var(--black); font-family: 'Inter', sans-serif; }

  .navbar {
    position: sticky; top: 0; z-index: 100;
    display: flex; align-items: center; gap: 2rem;
    padding: 0 2rem; height: 60px;
    background: var(--black);
    border-bottom: 3px solid var(--yellow);
  }
  .logo { display: flex; align-items: center; gap: 8px; text-decoration: none; }
  .logo-book { font-size: 1.4rem; }
  .logo-text { font-family: 'Playfair Display', serif; font-size: 1.3rem; color: #fff; font-weight: 700; letter-spacing: -0.5px; }
  .logo-accent { color: var(--yellow); }
  .nav-links { display: flex; gap: 1.5rem; margin-left: auto; }
  .nav-link { color: #c0a882; text-decoration: none; font-size: 0.9rem; font-weight: 500; padding: 4px 0; border-bottom: 2px solid transparent; transition: color .2s, border-color .2s; }
  .nav-link:hover { color: var(--yellow); }
  .nav-link.active { color: #fff; border-bottom-color: var(--red); }
  .nav-actions { display: flex; gap: 0.75rem; }
  .icon-btn { color: #c0a882; display: flex; align-items: center; justify-content: center; padding: 6px; border-radius: 6px; text-decoration: none; transition: color .2s, background .2s; }
  .icon-btn:hover { color: var(--yellow); background: #ffffff12; }

  .hero {
    background: var(--black);
    padding: 4rem 2rem 3.5rem;
    display: flex; align-items: center; justify-content: space-between;
    gap: 2rem; overflow: hidden; position: relative;
  }
  .hero-inner { flex: 1; max-width: 600px; }
  .hero-eyebrow { font-size: 0.78rem; font-weight: 600; letter-spacing: 2px; text-transform: uppercase; color: var(--yellow); margin-bottom: 1rem; }
  .hero-headline { font-family: 'Playfair Display', serif; font-size: clamp(2.2rem, 5vw, 3.4rem); font-weight: 900; line-height: 1.1; color: #fff; margin-bottom: 0.75rem; }
  .hero-accent { color: var(--yellow); }
  .hero-sub { color: #c0a882; font-size: 1rem; margin-bottom: 2rem; }

  .search-bar {
    display: flex; align-items: center; gap: 0.75rem;
    background: #fff; border-radius: 50px;
    padding: 0.6rem 1rem; max-width: 480px;
    box-shadow: 0 0 0 3px var(--yellow);
  }
  .search-icon { color: var(--muted); flex-shrink: 0; }
  .search-input { border: none; outline: none; flex: 1; font-size: 0.95rem; font-family: 'Inter', sans-serif; background: transparent; color: var(--black); }
  .clear-btn { background: none; border: none; cursor: pointer; color: var(--muted); font-size: 0.85rem; padding: 0 4px; }
  .clear-btn:hover { color: var(--red); }

  .hero-books-deco { display: flex; align-items: flex-end; gap: 6px; padding-right: 2rem; }
  .deco-book {
    width: 28px; height: 120px; border-radius: 3px;
    background: var(--c); opacity: 0.85;
    animation: riseUp 0.6s ease var(--delay) both;
  }
  .deco-book:nth-child(2) { height: 90px; }
  .deco-book:nth-child(3) { height: 140px; }
  .deco-book:nth-child(4) { height: 80px; }
  .deco-book:nth-child(5) { height: 110px; }
  @keyframes riseUp { from { transform: translateY(30px); opacity: 0; } to { opacity: .85; } }

  .main { max-width: 1280px; margin: 0 auto; padding: 2.5rem 2rem 4rem; }
  .section-header { display: flex; align-items: baseline; justify-content: space-between; margin-bottom: 1.75rem; }
  .section-title { font-family: 'Playfair Display', serif; font-size: 1.6rem; font-weight: 700; color: var(--black); }
  .book-count { font-size: 0.85rem; color: var(--muted); font-weight: 500; }

  .books-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    gap: 1.5rem;
  }

  .book-card {
    background: var(--card-bg); border-radius: var(--radius);
    border: 1px solid var(--border); overflow: hidden;
    transition: transform .25s ease, box-shadow .25s ease;
    cursor: pointer; position: relative;
  }
  .book-card:hover {
    transform: translateY(-6px) rotate(-0.8deg);
    box-shadow: 6px 12px 32px #1a100820;
  }

  .card-img-wrap { position: relative; aspect-ratio: 3/4; background: #f5ebe0; overflow: hidden; }
  .card-img { width: 100%; height: 100%; object-fit: cover; display: block; }
  .card-img-placeholder { width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; background: linear-gradient(135deg,#2a1f14,#4a3525); }
  .card-img-placeholder svg { width: 55%; height: auto; opacity: 0.9; }

  .discount-badge {
    position: absolute; top: 8px; left: 8px;
    background: var(--red); color: #fff;
    font-size: 0.7rem; font-weight: 700; letter-spacing: 0.5px;
    padding: 3px 7px; border-radius: 4px;
  }
  .status-chip {
    position: absolute; bottom: 8px; right: 8px;
    background: #000000aa; color: #fff; backdrop-filter: blur(4px);
    font-size: 0.65rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;
    padding: 3px 8px; border-radius: 20px;
  }
  .status-chip[data-status="sold"] { background: #e63946cc; }
  .status-chip[data-status="available"] { background: #2a6049cc; }

  .card-body { padding: 0.9rem; }
  .book-title { font-family: 'Playfair Display', serif; font-size: 0.95rem; font-weight: 700; line-height: 1.3; margin-bottom: 0.2rem; color: var(--black); display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
  .book-author { font-size: 0.78rem; color: var(--muted); margin-bottom: 0.7rem; }
  .price-row { display: flex; align-items: baseline; gap: 0.5rem; margin-bottom: 0.8rem; }
  .sell-price { font-size: 1.05rem; font-weight: 700; color: var(--red); }
  .orig-price { font-size: 0.8rem; color: var(--muted); text-decoration: line-through; }

  .add-cart-btn {
    width: 100%; padding: 0.5rem;
    background: var(--yellow); color: var(--black);
    border: none; border-radius: 6px;
    font-size: 0.82rem; font-weight: 700; cursor: pointer;
    transition: background .2s, transform .15s;
  }
  .add-cart-btn:hover { background: #e6b800; transform: scale(1.02); }

  .skeleton .card-img-wrap, .skeleton-block, .skeleton-line {
    background: linear-gradient(90deg, #ede8e2 25%, #f8f3ee 50%, #ede8e2 75%);
    background-size: 200% 100%;
    animation: shimmer 1.4s infinite;
    border-radius: 4px;
  }
  .skeleton-block { width: 100%; aspect-ratio: 3/4; }
  .skeleton .card-body { display: flex; flex-direction: column; gap: 8px; }
  .skeleton-line.wide { height: 14px; width: 90%; }
  .skeleton-line.mid { height: 12px; width: 60%; }
  .skeleton-line.narrow { height: 12px; width: 40%; }
  .skeleton-price-row { display: flex; gap: 8px; }
  .skeleton-line.price { height: 18px; width: 40%; }
  @keyframes shimmer { to { background-position: -200% 0; } }

  .error-box { display: flex; align-items: center; gap: 1rem; background: #fff0f0; border: 1px solid #ffcccc; border-radius: 8px; padding: 1rem 1.25rem; margin-bottom: 1.5rem; color: var(--red); }
  .empty-state { grid-column: 1/-1; text-align: center; padding: 4rem 2rem; color: var(--muted); }
  .empty-icon { font-size: 3rem; margin-bottom: 1rem; }
  .retry-btn { margin-top: 1rem; padding: 0.5rem 1.25rem; background: var(--black); color: var(--yellow); border: none; border-radius: 6px; font-size: 0.85rem; font-weight: 600; cursor: pointer; }

  .pagination { display: flex; align-items: center; justify-content: center; gap: 1.5rem; margin-top: 3rem; }
  .page-btn { padding: 0.55rem 1.4rem; background: var(--black); color: var(--yellow); border: none; border-radius: 6px; font-size: 0.9rem; font-weight: 600; cursor: pointer; transition: opacity .2s; }
  .page-btn:disabled { opacity: 0.35; cursor: not-allowed; }
  .page-info { font-size: 0.9rem; color: var(--muted); font-weight: 500; }

  .footer { background: var(--black); color: #8A7060; text-align: center; padding: 1.5rem; font-size: 0.82rem; }

  /* ── Tablet (768px) ── */
  @media (max-width: 768px) {
    .navbar { padding: 0 1rem; gap: 1rem; }
    .nav-links { gap: 0.75rem; }
    .hero { padding: 2.5rem 1.25rem 2rem; }
    .hero-inner { max-width: 100%; }
    .search-bar { max-width: 100%; }
    .books-grid { grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap: 1rem; }
    .main { padding: 2rem 1.25rem 3rem; }
  }

  /* ── Mobile (480px) ── */
  @media (max-width: 480px) {
    .navbar { padding: 0 0.75rem; height: 52px; }
    .logo-text { font-size: 1.1rem; }
    .nav-links { gap: 0.5rem; }
    .nav-link { font-size: 0.8rem; }
    .icon-btn { padding: 4px; }
    .hero { flex-direction: column; padding: 2rem 1rem 1.75rem; gap: 1rem; }
    .hero-headline { font-size: clamp(1.7rem, 7vw, 2.4rem); }
    .hero-books-deco { display: none; }
    .search-bar { padding: 0.5rem 0.85rem; }
    .section-header { flex-direction: column; align-items: flex-start; gap: 4px; }
    .section-title { font-size: 1.3rem; }
    .books-grid { grid-template-columns: repeat(2, 1fr); gap: 0.75rem; }
    .main { padding: 1.5rem 0.9rem 3rem; }
    .pagination { gap: 1rem; margin-top: 2rem; }
    .page-btn { padding: 0.45rem 1rem; font-size: 0.82rem; }
    .card-body { padding: 0.65rem; }
    .book-title { font-size: 0.82rem; }
    .sell-price { font-size: 0.95rem; }
    .add-cart-btn { font-size: 0.75rem; padding: 0.4rem; }
    .footer { padding: 1rem; font-size: 0.75rem; }
  }
`;