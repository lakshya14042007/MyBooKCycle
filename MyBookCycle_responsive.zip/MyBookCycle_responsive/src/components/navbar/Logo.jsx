import React from 'react'

const Logo = () => {
  const logocss={
    width:"150px",
    height:"150px",
    borderRadius:"50%",
    objectFit:"cover"
  }
  return (
    <img src="/Logo.png" alt="Logo" style={logocss} />
  )
}

export default Logo
