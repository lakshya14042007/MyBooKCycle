import React from 'react'
import useState from 'react'

const Mode = () => {
  const [mode, setMode] = React.useState("buyer");
  let buttoncss;
  if(mode === "buyer"){
    buttoncss={
      padding:"10px 20px",
      borderRadius:"5px",
      border:"none",
      backgroundColor:"red",
      color:"white",
      cursor:"pointer"
    }
  }else{
    buttoncss={
      padding:"10px 20px",
      borderRadius:"5px",
      border:"none",
      backgroundColor:"orange",
      color:"white",
      cursor:"pointer"
    }
  }
  return (
    <button onClick={() => setMode(mode === "buyer" ? "seller" : "buyer")} style={buttoncss}>
      {mode}
    </button>
  )
}

export default Mode
