import React from 'react'

const Searchbar = () => {
  return (
    <>
      <input type="text" placeholder='Search for books, authors, genres...' style={{width:"300px",padding:"10px",borderRadius:"5px",border:"1px solid #ccc"}}/>
    </>
  )
}

export default Searchbar
