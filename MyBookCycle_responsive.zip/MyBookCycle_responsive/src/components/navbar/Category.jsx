import React from 'react'

const Category = () => {
  const categoryarray = ["Fiction","Non-Fiction","Science Fiction","Fantasy","Mystery","Biography","History","Children's Books"];
  return (
    <select style={{
      padding: '6px 8px',
      borderRadius: '6px',
      border: '1px solid #ccc',
      fontSize: '14px',
      width: '100%',
      maxWidth: '200px',
      cursor: 'pointer',
    }}>
      <option value="">Select Category</option>
      {categoryarray.map((cat) => (
        <option key={cat} value={cat}>{cat}</option>
      ))}
    </select>
  );
};

export default Category;
