import React, { useContext, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../../context/AuthContext';
import Logo from './Logo';
import Searchbar from '../Search/Searchbar';
import Category from './Category';
import Navlinks from './Navlinks';

const NavComponent = () => {
  const { isAuthenticated, logout } = useContext(AuthContext);
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/login', { replace: true });
    setMenuOpen(false);
  };

  return (
    <>
      <style>{`
        .nav-root {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 0 20px;
          background-color: yellow;
          height: 64px;
          position: sticky;
          top: 0;
          z-index: 200;
          box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }
        .nav-logo { flex-shrink: 0; }
        .nav-desktop-links { display: flex; align-items: center; gap: 20px; }
        .nav-hamburger {
          display: none;
          background: none;
          border: none;
          cursor: pointer;
          padding: 6px;
          flex-direction: column;
          gap: 5px;
          border-radius: 6px;
        }
        .nav-hamburger span {
          display: block; width: 24px; height: 2.5px;
          background: #1a1008; border-radius: 2px;
          transition: all 0.25s ease;
        }
        .nav-hamburger.open span:nth-child(1) { transform: translateY(7.5px) rotate(45deg); }
        .nav-hamburger.open span:nth-child(2) { opacity: 0; }
        .nav-hamburger.open span:nth-child(3) { transform: translateY(-7.5px) rotate(-45deg); }

        .nav-drawer {
          display: none;
          position: fixed;
          top: 64px; left: 0; right: 0;
          background: #fef08a;
          border-top: 2px solid #facc15;
          box-shadow: 0 8px 24px rgba(0,0,0,0.12);
          padding: 16px 20px 24px;
          z-index: 199;
          flex-direction: column;
          gap: 0;
          animation: slideDown 0.2s ease;
        }
        .nav-drawer.open { display: flex; }
        @keyframes slideDown {
          from { opacity: 0; transform: translateY(-8px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        .drawer-section {
          padding: 10px 0;
          border-bottom: 1px solid rgba(0,0,0,0.08);
        }
        .drawer-section:last-child { border-bottom: none; }

        .nav-logout-btn {
          background: #1a1008; color: #fff;
          border: none; padding: 8px 15px;
          border-radius: 6px; font-weight: 700;
          cursor: pointer; font-size: 14px;
          transition: background 0.2s;
          white-space: nowrap;
        }
        .nav-logout-btn:hover { background: #ff4d4d; }

        @media (max-width: 768px) {
          .nav-desktop-links { display: none; }
          .nav-hamburger { display: flex; }
        }
        @media (max-width: 480px) {
          .nav-root { padding: 0 14px; height: 58px; }
          .nav-drawer { top: 58px; padding: 12px 16px 20px; }
        }
      `}</style>

      <div className="nav-root">
        <div className="nav-logo"><Logo /></div>

        {/* Desktop layout */}
        <div className="nav-desktop-links">
          <Navlinks />
          <Category />
          <Searchbar />
          {isAuthenticated && (
            <button className="nav-logout-btn" onClick={handleLogout}
              onMouseOver={e => e.target.style.backgroundColor = '#ff4d4d'}
              onMouseOut={e => e.target.style.backgroundColor = '#1a1a1a'}>
              Logout
            </button>
          )}
        </div>

        {/* Hamburger */}
        <button
          className={`nav-hamburger${menuOpen ? ' open' : ''}`}
          onClick={() => setMenuOpen(o => !o)}
          aria-label="Toggle menu"
        >
          <span /><span /><span />
        </button>
      </div>

      {/* Mobile drawer */}
      <div className={`nav-drawer${menuOpen ? ' open' : ''}`}>
        <div className="drawer-section">
          <Navlinks onLinkClick={() => setMenuOpen(false)} />
        </div>
        <div className="drawer-section" style={{ paddingTop: 14 }}>
          <Category />
        </div>
        <div className="drawer-section" style={{ paddingTop: 14 }}>
          <Searchbar onSearch={() => setMenuOpen(false)} />
        </div>
        {isAuthenticated && (
          <div className="drawer-section" style={{ paddingTop: 14 }}>
            <button className="nav-logout-btn" onClick={handleLogout} style={{ width: '100%' }}>
              Logout
            </button>
          </div>
        )}
      </div>
    </>
  );
};

export default NavComponent;
