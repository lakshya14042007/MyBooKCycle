import React from 'react';
import { NavLink } from 'react-router-dom';
import './Navlinks.css';

const Navlinks = ({ onLinkClick }) => {
  return (
    <nav className="nav-container">
      <ul className="nav-list">
        <li>
          <NavLink
            to="/"
            className={({ isActive }) => isActive ? 'nav-item active' : 'nav-item'}
            onClick={onLinkClick}
          >Home</NavLink>
        </li>
        <li>
          <NavLink
            to="/add-book"
            className={({ isActive }) => isActive ? 'nav-item active' : 'nav-item'}
            onClick={onLinkClick}
          >Sell Book</NavLink>
        </li>
      </ul>
    </nav>
  );
};

export default Navlinks;
