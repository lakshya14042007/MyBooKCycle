import React from 'react';
import { Outlet } from 'react-router-dom';

const App = () => {
    return (
        <div className="system-root">
            <Outlet />
        </div>
    );
};

export default App;