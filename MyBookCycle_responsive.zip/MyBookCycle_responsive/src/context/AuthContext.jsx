import React, { createContext, useState, useEffect } from 'react';
import apiClient from '../api/axiosConfig';

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [isLoading, setIsLoading] = useState(true); // Prevents UI rendering before auth check

    // Check auth status on initial application load
    useEffect(() => {
        const token = localStorage.getItem('token');
        if (token) {
            setIsAuthenticated(true);
        }
        setIsLoading(false);
    }, []);

    // Standardized login execution
    const login = async (email, password) => {
        try {
            // Notice: Using the standard axios here, not apiClient, 
            // because login doesn't require a token.
            const response = await apiClient.post('/auth/login', { email, password });
            const token = response.data.token;
            
            localStorage.setItem('token', token);
            setIsAuthenticated(true);
            return { success: true };
        } catch (error) {
            return { 
                success: false, 
                message: error.response?.data || "Login failed due to network anomaly." 
            };
        }
    };

    // Standardized logout execution
    const logout = () => {
        localStorage.removeItem('token');
        setIsAuthenticated(false);
    };

    if (isLoading) {
        return <div>Loading System Variables...</div>; 
    }

    return (
        <AuthContext.Provider value={{ isAuthenticated, login, logout }}>
            {children}
        </AuthContext.Provider>
    );
};