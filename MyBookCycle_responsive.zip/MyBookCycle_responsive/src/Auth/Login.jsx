import React, { useState, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import './login.css'; // Importing the new CSS file for styling

const Login = () => {
    console.log("Rendering Login Component");
    const [credentials, setCredentials] = useState({ email: '', password: '' });
    const [errorMsg, setErrorMsg] = useState('');
    
    // Extracting the login mechanism from our global state
    const { login } = useContext(AuthContext);
    const navigate = useNavigate();

    const handleChange = (e) => {
        setCredentials({
            ...credentials,
            [e.target.name]: e.target.value
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setErrorMsg(''); // Reset error state on new attempt
        
        // Execute the login protocol via Context API
        const result = await login(credentials.email, credentials.password);
        
        if (result.success) {
            // Authentication verified, rerouting to secure zone
            navigate('/');
        } else {
            // Displaying specific error from the backend
            setErrorMsg(result.message);
        }
    };

    return (
        <div className="login-wrapper"> {/* New wrapper for background */}
            <div className="login-auth-container"> {/* Modified existing class */}
                <h2 className="login-heading">WELCOME BACK</h2> {/* Added class */}
                <form onSubmit={handleSubmit} className="login-form"> {/* Added class */}
                    <div className="login-form-group">
                        <label className="login-label">Email Identification</label>
                        <input 
                            type="email" 
                            name="email" 
                            className="login-input" // Added class
                            value={credentials.email} 
                            onChange={handleChange} 
                            required 
                        />
                    </div>
                    <div className="login-form-group">
                        <label className="login-label">Security Key (Password)</label>
                        <input 
                            type="password" 
                            name="password" 
                            className="login-input" // Added class
                            value={credentials.password} 
                            onChange={handleChange} 
                            required 
                        />
                    </div>
                    <button type="submit" className="login-btn-submit">Authenticate</button>
                    <h3 className="login-register-link">Don't have an account? <a href="/register">Register Here</a></h3> {/* Added class */}
                </form>
                {errorMsg && <div className="login-error-message">{errorMsg}</div>} {/* Styled error */}
            </div>
        </div>
    );
};

export default Login;

