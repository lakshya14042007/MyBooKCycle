import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import apiClient from '../api/axiosConfig';
import './register.css'; // Importing the new CSS file for styling

const Register = () => {
    const [formData, setFormData] = useState({ name: '', email: '', password: '' });
    const [statusMsg, setStatusMsg] = useState({ text: '', isError: false });
    const navigate = useNavigate();

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        try {
            // Utilizing the configured interceptor client for the request
            await apiClient.post('/auth/register', formData);
            
            setStatusMsg({ text: "Identity created. Rerouting to login...", isError: false });
            
            // Strategic delay to allow the user to read the success message
            setTimeout(() => {
                navigate('/login');
            }, 2000);
            
        } catch (error) {
            const errorText = error.response?.data || "Registration sequence failed.";
            setStatusMsg({ text: errorText, isError: true });
        }
    };

    return (
        <div className="register-wrapper">
            <div className="register-auth-container">
                <h2 className="register-heading">Initialize Identity</h2>
                <form onSubmit={handleSubmit} className="register-form">
                    <div className="register-form-group">
                        <label className="register-label">Full Name</label>
                        <input 
                            type="text" 
                            name="name" 
                            className="register-input"
                            value={formData.name} 
                            onChange={handleChange} 
                            required 
                        />
                    </div>
                    <div className="register-form-group">
                        <label className="register-label">Email</label>
                        <input 
                            type="email" 
                            name="email" 
                            className="register-input"
                            value={formData.email} 
                            onChange={handleChange} 
                            required 
                        />
                    </div>
                    <div className="register-form-group">
                        <label className="register-label">Password</label>
                        <input 
                            type="password" 
                            name="password" 
                            className="register-input"
                            value={formData.password} 
                            onChange={handleChange} 
                            required 
                        />
                    </div>
                    <button type="submit" className="register-btn-submit">Initialize</button>
                </form>
                {statusMsg.text && (
                    <div className={`register-status-message ${statusMsg.isError ? 'error' : 'success'}`}>
                        {statusMsg.text}
                    </div>
                )}
            </div>
        </div>
    );
};

export default Register;