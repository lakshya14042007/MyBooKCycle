import axios from 'axios';

// Create a centralized Axios instance
const apiClient = axios.create({
    baseURL: 'http://localhost:8080/api', // Base URL for your Spring Boot backend
});

// Request Interceptor: Runs before every API call
apiClient.interceptors.request.use(
    (config) => {
        // Retrieve the token from LocalStorage
        const token = localStorage.getItem('token');
        
        // If the token exists, attach it to the Authorization header
        if (token) {
            config.headers['Authorization'] = `Bearer ${token}`;
        }
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

// Response Interceptor: Handles global errors (like expired tokens)
apiClient.interceptors.response.use(
    (response) => {
        return response; // If successful, pass the response through
    },
    (error) => {
        // If the backend rejects the token (401 Unauthorized), force a logout
        if (error.response && error.response.status === 401) {
            console.error("Token expired or invalid. Terminating session.");
            localStorage.removeItem('token');
            window.location.href = '/login'; // Redirect to login immediately
        }
        return Promise.reject(error);
    }
);

export default apiClient;