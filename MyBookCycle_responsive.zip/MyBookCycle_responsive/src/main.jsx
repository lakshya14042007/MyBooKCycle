import { createRoot } from "react-dom/client";
import { RouterProvider } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import routes from "./routes/Route";

createRoot(document.getElementById("root")).render(
    <AuthProvider>
        <RouterProvider router={routes} />
    </AuthProvider>
);